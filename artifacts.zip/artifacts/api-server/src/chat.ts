import { WebSocketServer, WebSocket } from "ws";
import type { IncomingMessage, Server } from "http";
import { logger } from "./lib/logger";

interface ChatMsg {
  type: "message" | "system" | "history";
  name?: string;
  text?: string;
  time: number;
  messages?: ChatMsg[];
}

const MAX_HISTORY = 80;
const history: ChatMsg[] = [];
const clients = new Map<WebSocket, string>();
let onlineCount = 0;

function broadcast(msg: ChatMsg, exclude?: WebSocket) {
  const data = JSON.stringify(msg);
  for (const [ws] of clients) {
    if (ws !== exclude && ws.readyState === WebSocket.OPEN) {
      ws.send(data);
    }
  }
}

function pushHistory(msg: ChatMsg) {
  history.push(msg);
  if (history.length > MAX_HISTORY) history.shift();
}

export function setupChat(server: Server): void {
  const wss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (req: IncomingMessage, socket, head) => {
    const url = req.url ?? "";
    if (url.startsWith("/api/chat")) {
      wss.handleUpgrade(req, socket as never, head, (ws) => {
        wss.emit("connection", ws, req);
      });
    } else {
      socket.destroy();
    }
  });

  wss.on("connection", (ws: WebSocket) => {
    let username = "";
    onlineCount++;

    ws.send(JSON.stringify({ type: "history", messages: history, time: Date.now() }));

    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString()) as { type: string; name?: string; text?: string };

        if (msg.type === "join") {
          username = String(msg.name ?? "訪客").trim().slice(0, 18) || "訪客";
          clients.set(ws, username);
          const m: ChatMsg = { type: "system", text: `${username} 加入了聊天室`, time: Date.now() };
          pushHistory(m);
          broadcast(m);

        } else if (msg.type === "message" && username) {
          const text = String(msg.text ?? "").trim().slice(0, 200);
          if (!text) return;
          const m: ChatMsg = { type: "message", name: username, text, time: Date.now() };
          pushHistory(m);
          broadcast(m);
        }
      } catch {
        // ignore malformed
      }
    });

    ws.on("close", () => {
      onlineCount = Math.max(0, onlineCount - 1);
      const name = clients.get(ws) ?? username;
      clients.delete(ws);
      if (name) {
        const m: ChatMsg = { type: "system", text: `${name} 離開了聊天室`, time: Date.now() };
        pushHistory(m);
        broadcast(m);
      }
      logger.debug({ onlineCount }, "Chat client disconnected");
    });

    logger.debug({ onlineCount }, "Chat client connected");
  });

  logger.info("Chat WebSocket server ready at /api/chat");
}
