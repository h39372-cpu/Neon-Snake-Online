import { useEffect, useRef, useState } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ClerkProvider, SignIn, SignUp, Show, useClerk, useUser } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { dark } from "@clerk/themes";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import SoloGame from "@/pages/SoloGame";
import BattleGame from "@/pages/BattleGame";
import NotFound from "@/pages/not-found";
import ChatRoom from "@/components/chat/ChatRoom";

const queryClient = new QueryClient();

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

const clerkAppearance = {
  baseTheme: dark,
  cssLayerName: "clerk" as const,
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#00ffff",
    colorForeground: "#e0ffff",
    colorMutedForeground: "#7a9ea0",
    colorDanger: "#ff4466",
    colorBackground: "#050510",
    colorInput: "#0d0d1a",
    colorInputForeground: "#e0ffff",
    colorNeutral: "#1a2a2a",
    fontFamily: "monospace",
    borderRadius: "0px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "w-[420px] max-w-full overflow-hidden border border-cyan-900/40" ,
    card: "!shadow-none !border-0 !bg-[#050510] !rounded-none",
    footer: "!shadow-none !border-0 !bg-[#050510] !rounded-none",
    headerTitle: "text-cyan-300 font-black tracking-widest",
    headerSubtitle: "text-cyan-700 tracking-wider",
    socialButtonsBlockButtonText: "text-white font-bold tracking-wide",
    formFieldLabel: "text-cyan-400 tracking-wider text-xs",
    footerActionLink: "text-cyan-400 hover:text-cyan-200",
    footerActionText: "text-cyan-800",
    dividerText: "text-cyan-900 tracking-widest text-xs",
    identityPreviewEditButton: "text-cyan-400",
    formFieldSuccessText: "text-cyan-400",
    alertText: "text-red-400",
    logoBox: "flex justify-center py-2",
    logoImage: "h-10",
    socialButtonsBlockButton: "border border-white/20 bg-white/5 hover:bg-white/10 transition-all",
    formButtonPrimary: "bg-cyan-500 hover:bg-cyan-400 text-black font-black tracking-widest transition-all",
    formFieldInput: "bg-[#0d0d1a] border border-cyan-900/50 text-cyan-100 tracking-wider",
    footerAction: "bg-transparent",
    dividerLine: "bg-cyan-900/30",
    alert: "border border-red-900/40 bg-red-950/20",
    otpCodeFieldInput: "bg-[#0d0d1a] border border-cyan-900/50 text-cyan-100",
    formFieldRow: "gap-2",
    main: "gap-4",
  },
};

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function SignInPage() {
  return (
    <div
      className="flex min-h-screen items-center justify-center relative"
      style={{ background: "#050510" }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,255,0.04) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        forceRedirectUrl={basePath || "/"}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div
      className="flex min-h-screen items-center justify-center relative"
      style={{ background: "#050510" }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,255,0.04) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        forceRedirectUrl={basePath || "/"}
      />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/solo" component={SoloGame} />
      <Route path="/battle/:rule" component={BattleGame} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey!}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "歡迎回來",
            subtitle: "登入以繼續遊戲",
          },
        },
        signUp: {
          start: {
            title: "建立帳號",
            subtitle: "開始你的霓虹蛇之旅",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />
          <Router />
          <ChatRoom />
        </TooltipProvider>
        <Toaster />
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
