import { useState, useEffect, useRef, useCallback } from "react";
import { MessageCircle, X, Send, User } from "lucide-react";

interface ChatMsg {
  type: "message" | "system" | "history";
  name?: string;
  text?: string;
  time: number;
  messages?: ChatMsg[];
}

function formatTime(ts: number) {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

const WS_URL = `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}/api/chat`;
const STORED_NAME_KEY = "neonSnakeChatName";

export default function ChatRoom() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [username, setUsername] = useState(() => localStorage.getItem(STORED_NAME_KEY) ?? "");
  const [nameInput, setNameInput] = useState("");
  const [joined, setJoined] = useState(false);
  const [unread, setUnread] = useState(0);
  const [connected, setConnected] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
    });
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        if (username) {
          ws.send(JSON.stringify({ type: "join", name: username }));
          setJoined(true);
        }
      };

      ws.onmessage = (e) => {
        try {
          const msg: ChatMsg = JSON.parse(e.data);
          if (msg.type === "history" && msg.messages) {
            setMessages(msg.messages);
            scrollToBottom();
          } else {
            setMessages((prev) => [...prev, msg]);
            if (!open) setUnread((u) => u + 1);
            scrollToBottom();
          }
        } catch { /* ignore */ }
      };

      ws.onclose = () => {
        setConnected(false);
        setJoined(false);
        reconnectTimer.current = setTimeout(connect, 3000);
      };

      ws.onerror = () => ws.close();
    } catch { /* ignore */ }
  }, [username, open, scrollToBottom]);

  // Connect on mount
  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Scroll to bottom when opening
  useEffect(() => {
    if (open) { setUnread(0); scrollToBottom(); }
  }, [open, scrollToBottom]);

  useEffect(() => { scrollToBottom(); }, [messages, scrollToBottom]);

  const handleJoin = useCallback(() => {
    const name = nameInput.trim().slice(0, 18);
    if (!name) return;
    setUsername(name);
    localStorage.setItem(STORED_NAME_KEY, name);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "join", name }));
      setJoined(true);
    }
  }, [nameInput]);

  const handleSend = useCallback(() => {
    const text = input.trim();
    if (!text || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(JSON.stringify({ type: "message", text }));
    setInput("");
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };
  const handleJoinKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { e.preventDefault(); handleJoin(); }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end gap-2" data-testid="chat-room">
      {/* Panel */}
      {open && (
        <div
          className="flex flex-col overflow-hidden"
          style={{
            width: 300,
            height: 420,
            background: "rgba(5,5,20,0.97)",
            border: "1px solid rgba(0,255,255,0.25)",
            boxShadow: "0 0 30px rgba(0,255,255,0.15), 0 8px 32px rgba(0,0,0,0.6)",
            borderRadius: 6,
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-3 py-2 shrink-0"
            style={{ borderBottom: "1px solid rgba(0,255,255,0.12)", background: "rgba(0,255,255,0.04)" }}
          >
            <div className="flex items-center gap-2">
              <MessageCircle size={14} style={{ color: "#00ffff" }} />
              <span className="text-sm font-bold tracking-widest" style={{ color: "#00ffff" }}>聊天室</span>
              <span
                className="text-[10px] px-1.5 py-0.5 rounded-full"
                style={{
                  background: connected ? "rgba(0,255,100,0.15)" : "rgba(255,100,0,0.15)",
                  color: connected ? "#00ff88" : "#ff8800",
                  border: `1px solid ${connected ? "rgba(0,255,100,0.3)" : "rgba(255,100,0,0.3)"}`,
                }}
              >
                {connected ? "已連線" : "連線中..."}
              </span>
            </div>
            <button onClick={() => setOpen(false)} className="p-0.5 text-muted-foreground/50 hover:text-foreground transition-colors">
              <X size={14} />
            </button>
          </div>

          {/* Username entry */}
          {!joined ? (
            <div className="flex flex-col items-center justify-center flex-1 gap-4 px-4">
              <User size={28} style={{ color: "rgba(0,255,255,0.4)" }} />
              <p className="text-sm text-muted-foreground tracking-wider text-center">輸入你的名稱加入聊天室</p>
              <input
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                onKeyDown={handleJoinKey}
                placeholder="你的名稱..."
                maxLength={18}
                className="w-full bg-transparent text-sm text-center py-2 px-3 outline-none"
                style={{ border: "1px solid rgba(0,255,255,0.3)", color: "#00ffff", borderRadius: 3 }}
                autoFocus
              />
              <button
                onClick={handleJoin}
                disabled={!nameInput.trim()}
                className="w-full py-2 text-sm font-bold tracking-widest transition-all"
                style={{
                  borderRadius: 3,
                  background: nameInput.trim() ? "rgba(0,255,255,0.12)" : "rgba(0,255,255,0.03)",
                  border: `1px solid ${nameInput.trim() ? "#00ffff" : "rgba(0,255,255,0.15)"}`,
                  color: nameInput.trim() ? "#00ffff" : "rgba(0,255,255,0.3)",
                  cursor: nameInput.trim() ? "pointer" : "not-allowed",
                }}
              >
                加入聊天
              </button>
            </div>
          ) : (
            <>
              {/* Message list */}
              <div ref={listRef} className="flex-1 overflow-y-auto px-2 py-2 space-y-1.5" style={{ scrollbarWidth: "thin" }}>
                {messages.length === 0 && (
                  <p className="text-center text-xs text-muted-foreground/30 mt-8 tracking-wider">還沒有人說話…</p>
                )}
                {messages.map((msg, i) => {
                  if (msg.type === "system") {
                    return (
                      <div key={i} className="text-center text-[10px] text-muted-foreground/40 tracking-wider py-0.5">
                        {msg.text}
                      </div>
                    );
                  }
                  const isOwn = msg.name === username;
                  return (
                    <div key={i} className={`flex flex-col ${isOwn ? "items-end" : "items-start"}`}>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        {!isOwn && (
                          <span className="text-[10px] font-bold" style={{ color: "rgba(0,255,255,0.7)" }}>
                            {msg.name}
                          </span>
                        )}
                        <span className="text-[9px] text-muted-foreground/30">{formatTime(msg.time)}</span>
                        {isOwn && (
                          <span className="text-[10px] font-bold" style={{ color: "rgba(255,68,204,0.7)" }}>
                            {msg.name}
                          </span>
                        )}
                      </div>
                      <div
                        className="text-xs px-2.5 py-1.5 max-w-[85%] break-words"
                        style={{
                          borderRadius: isOwn ? "8px 2px 8px 8px" : "2px 8px 8px 8px",
                          background: isOwn ? "rgba(255,68,204,0.12)" : "rgba(0,255,255,0.08)",
                          border: `1px solid ${isOwn ? "rgba(255,68,204,0.25)" : "rgba(0,255,255,0.15)"}`,
                          color: isOwn ? "#ff88dd" : "rgba(255,255,255,0.85)",
                        }}
                      >
                        {msg.text}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Input */}
              <div
                className="flex items-center gap-2 px-2 py-2 shrink-0"
                style={{ borderTop: "1px solid rgba(0,255,255,0.1)" }}
              >
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="說些什麼..."
                  maxLength={200}
                  className="flex-1 bg-transparent text-xs py-1.5 px-2 outline-none"
                  style={{ border: "1px solid rgba(0,255,255,0.2)", color: "rgba(255,255,255,0.85)", borderRadius: 3 }}
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className="p-1.5 transition-all"
                  style={{ color: input.trim() ? "#00ffff" : "rgba(0,255,255,0.2)" }}
                >
                  <Send size={14} />
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* Toggle button */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative flex items-center justify-center w-12 h-12 transition-all"
        style={{
          borderRadius: "50%",
          background: open ? "rgba(0,255,255,0.15)" : "rgba(5,5,20,0.95)",
          border: "2px solid rgba(0,255,255,0.4)",
          boxShadow: open ? "0 0 16px rgba(0,255,255,0.4)" : "0 0 8px rgba(0,255,255,0.2)",
          color: "#00ffff",
        }}
        title="聊天室"
        data-testid="chat-toggle"
      >
        {open ? <X size={18} /> : <MessageCircle size={18} />}
        {!open && unread > 0 && (
          <span
            className="absolute -top-1 -right-1 flex items-center justify-center text-[10px] font-black rounded-full"
            style={{ width: 18, height: 18, background: "#ff00cc", color: "#fff", boxShadow: "0 0 6px #ff00cc" }}
          >
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
    </div>
  );
}
