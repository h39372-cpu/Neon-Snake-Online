import { useEffect, useRef } from "react";
import type { Point } from "@/hooks/useBattleGame";

interface BattleCanvasProps {
  snake1: Point[];
  snake2: Point[];
  foods: Point[];
  gridSize: number;
  tick: number;
}

const CELL_PAD = 1;

function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number, r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawSnake(
  ctx: CanvasRenderingContext2D,
  snake: Point[],
  cellSize: number,
  headColor: string,
  bodyR: number,
  bodyG: number,
  bodyB: number,
  glowColor: string
) {
  const len = snake.length;
  snake.forEach((seg, i) => {
    const x = seg.x * cellSize + CELL_PAD;
    const y = seg.y * cellSize + CELL_PAD;
    const w = cellSize - CELL_PAD * 2;
    const h = cellSize - CELL_PAD * 2;
    const r = Math.max(1.5, cellSize * 0.2);
    const t = i / Math.max(len - 1, 1);
    const brightness = 1 - t * 0.55;

    if (i === 0) {
      // Head
      ctx.shadowBlur = 16;
      ctx.shadowColor = glowColor;
      ctx.fillStyle = headColor;
      drawRoundRect(ctx, x, y, w, h, r);
      ctx.fill();
      // Eyes
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#000020";
      const eyeR = cellSize * 0.08;
      const cx = seg.x * cellSize + cellSize / 2;
      const cy = seg.y * cellSize + cellSize / 2;
      ctx.beginPath();
      ctx.arc(cx - cellSize * 0.2, cy - cellSize * 0.2, eyeR, 0, Math.PI * 2);
      ctx.arc(cx + cellSize * 0.2, cy - cellSize * 0.2, eyeR, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.shadowBlur = 6 * brightness;
      ctx.shadowColor = `rgba(${bodyR}, ${bodyG}, ${bodyB}, ${brightness * 0.8})`;
      ctx.fillStyle = `rgba(${bodyR}, ${bodyG}, ${bodyB}, ${brightness})`;
      drawRoundRect(ctx, x, y, w, h, r);
      ctx.fill();
      // Inner highlight
      if (cellSize > 8) {
        ctx.shadowBlur = 0;
        ctx.fillStyle = `rgba(255,255,255, ${0.12 * brightness})`;
        drawRoundRect(ctx, x + 1, y + 1, w - 2, h * 0.35, r * 0.6);
        ctx.fill();
      }
    }
  });
}

export default function BattleCanvas({ snake1, snake2, foods, gridSize, tick }: BattleCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const foodPulseRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const size = canvas.width;
    const cellSize = size / gridSize;

    foodPulseRef.current += 0.1;
    const pulse = Math.sin(foodPulseRef.current) * 0.3 + 0.7;

    // Background
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "#050510";
    ctx.fillRect(0, 0, size, size);

    // Center dividing line (visual separator)
    ctx.strokeStyle = "rgba(100, 100, 150, 0.08)";
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 8]);
    ctx.beginPath();
    ctx.moveTo(size / 2, 0);
    ctx.lineTo(size / 2, size);
    ctx.stroke();
    ctx.setLineDash([]);

    // Grid
    ctx.strokeStyle = "rgba(0, 255, 255, 0.04)";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= gridSize; i++) {
      const pos = i * cellSize;
      ctx.beginPath(); ctx.moveTo(pos, 0); ctx.lineTo(pos, size); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, pos); ctx.lineTo(size, pos); ctx.stroke();
    }

    // Foods (yellow-green neon)
    foods.forEach((food) => {
      const fx = food.x * cellSize + cellSize / 2;
      const fy = food.y * cellSize + cellSize / 2;
      const fr = (cellSize / 2 - CELL_PAD) * pulse;

      ctx.shadowBlur = 16 * pulse;
      ctx.shadowColor = "#aaff00";
      ctx.fillStyle = `rgba(180, 255, 0, ${0.25 * pulse})`;
      ctx.beginPath(); ctx.arc(fx, fy, fr * 1.4, 0, Math.PI * 2); ctx.fill();

      const foodGrad = ctx.createRadialGradient(fx, fy, 0, fx, fy, fr);
      foodGrad.addColorStop(0, "#ffffff");
      foodGrad.addColorStop(0.4, "#ccff44");
      foodGrad.addColorStop(1, "#88ff00");
      ctx.shadowBlur = 10 * pulse;
      ctx.shadowColor = "#88ff00";
      ctx.fillStyle = foodGrad;
      ctx.beginPath(); ctx.arc(fx, fy, fr, 0, Math.PI * 2); ctx.fill();
    });

    ctx.shadowBlur = 0;

    // P2 snake (magenta/pink) drawn first so P1 appears on top
    drawSnake(ctx, snake2, cellSize, "#ff44cc", 220, 0, 200, "#ff00cc");
    ctx.shadowBlur = 0;

    // P1 snake (cyan)
    drawSnake(ctx, snake1, cellSize, "#44ffff", 0, 200, 200, "#00ffcc");
    ctx.shadowBlur = 0;

    // Player zone labels (subtle)
    ctx.font = `bold ${Math.max(8, cellSize * 1.5)}px monospace`;
    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(0,255,255,0.06)";
    ctx.fillText("P1", cellSize * 0.5, cellSize * 2);
    ctx.textAlign = "right";
    ctx.fillStyle = "rgba(255,0,200,0.06)";
    ctx.fillText("P2", size - cellSize * 0.5, size - cellSize * 0.5);
    ctx.textAlign = "left";

  }, [snake1, snake2, foods, gridSize, tick]);

  const canvasSize = Math.min(
    typeof window !== "undefined" ? Math.min(window.innerWidth - 32, window.innerHeight - 200) : 480,
    520
  );
  const snappedSize = Math.floor(canvasSize / gridSize) * gridSize;

  return (
    <canvas
      ref={canvasRef}
      width={snappedSize}
      height={snappedSize}
      className="block"
      style={{
        width: snappedSize,
        height: snappedSize,
        imageRendering: "pixelated",
        border: "2px solid transparent",
        borderImage: "linear-gradient(135deg, #00ffff, #ff00cc) 1",
        boxShadow: "0 0 30px rgba(0,255,255,0.2), 0 0 30px rgba(255,0,200,0.2), 0 0 80px rgba(0,100,100,0.1)",
      }}
      data-testid="battle-canvas"
    />
  );
}
