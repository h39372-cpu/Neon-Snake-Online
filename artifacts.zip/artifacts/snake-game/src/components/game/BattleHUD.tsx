import { Pause, Music, VolumeX, Volume2, Music2, Swords } from "lucide-react";
import type { BattleSettings, BattleRule } from "@/hooks/useBattleGame";

interface BattleHUDProps {
  score1: number;
  score2: number;
  len1: number;
  len2: number;
  settings: BattleSettings;
  onPause: () => void;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
}

const RULE_LABELS: Record<BattleRule, string> = {
  elimination: "致命模式",
  absorption: "吞噬模式",
};

export default function BattleHUD({
  score1, score2, len1, len2, settings,
  onPause, onToggleMusic, onToggleSfx,
}: BattleHUDProps) {
  return (
    <div className="flex items-center justify-between w-full px-1 py-2" data-testid="battle-hud">
      {/* P1 score */}
      <div className="flex gap-3 text-xs tracking-widest" data-testid="p1-stats">
        <div>
          <div className="text-[10px]" style={{ color: "rgba(0,255,255,0.5)" }}>P1 分數</div>
          <div className="font-black text-lg leading-none" style={{ color: "#00ffff", textShadow: "0 0 8px #00ffff" }}>
            {score1}
          </div>
        </div>
        <div>
          <div className="text-[10px]" style={{ color: "rgba(0,255,255,0.5)" }}>長度</div>
          <div className="font-black text-base leading-none text-foreground/60">{len1}</div>
        </div>
      </div>

      {/* Center: mode + controls */}
      <div className="flex flex-col items-center gap-1">
        <div className="flex items-center gap-1 text-[10px] tracking-widest text-muted-foreground/50">
          <Swords size={10} />
          <span>{RULE_LABELS[settings.rule]}</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onToggleMusic} data-testid="hud-toggle-music"
            className="p-1 transition-colors"
            style={{ color: settings.musicEnabled ? "#00ffff" : "rgba(150,150,170,0.4)" }}>
            {settings.musicEnabled ? <Music size={12} /> : <Music2 size={12} />}
          </button>
          <button onClick={onToggleSfx} data-testid="hud-toggle-sfx"
            className="p-1 transition-colors"
            style={{ color: settings.sfxEnabled ? "#ff00cc" : "rgba(150,150,170,0.4)" }}>
            {settings.sfxEnabled ? <Volume2 size={12} /> : <VolumeX size={12} />}
          </button>
          <button onClick={onPause} data-testid="button-pause-battle"
            className="flex items-center gap-1 px-2 py-1 border text-[10px] font-bold tracking-widest transition-all"
            style={{ borderColor: "rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.5)" }}>
            <Pause size={10} /> 暫停
          </button>
        </div>
      </div>

      {/* P2 score */}
      <div className="flex gap-3 text-xs tracking-widest text-right" data-testid="p2-stats">
        <div>
          <div className="text-[10px]" style={{ color: "rgba(255,0,200,0.5)" }}>長度</div>
          <div className="font-black text-base leading-none text-foreground/60">{len2}</div>
        </div>
        <div>
          <div className="text-[10px]" style={{ color: "rgba(255,0,200,0.5)" }}>P2 分數</div>
          <div className="font-black text-lg leading-none" style={{ color: "#ff44cc", textShadow: "0 0 8px #ff00cc" }}>
            {score2}
          </div>
        </div>
      </div>
    </div>
  );
}
