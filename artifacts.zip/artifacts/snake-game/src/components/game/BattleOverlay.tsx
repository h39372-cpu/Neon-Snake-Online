import { RotateCcw, Home, Swords, Trophy } from "lucide-react";
import { useEffect, useState } from "react";
import type { Winner } from "@/hooks/useBattleGame";

interface BattleOverlayProps {
  winner: Winner;
  score1: number;
  score2: number;
  len1: number;
  len2: number;
  onRestart: () => void;
  onMenu: () => void;
}

const WINNER_CONFIG: Record<
  NonNullable<Winner>,
  { label: string; sublabel: string; color: string; glow: string }
> = {
  p1: { label: "P1 獲勝!", sublabel: "PLAYER 1 WINS", color: "#00ffff", glow: "#00ffff" },
  p2: { label: "P2 獲勝!", sublabel: "PLAYER 2 WINS", color: "#ff44cc", glow: "#ff00cc" },
  draw: { label: "平局!", sublabel: "DRAW", color: "#ffff00", glow: "#ffcc00" },
};

export default function BattleOverlay({
  winner, score1, score2, len1, len2, onRestart, onMenu,
}: BattleOverlayProps) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 150);
    return () => clearTimeout(t);
  }, []);

  if (!winner) return null;
  const cfg = WINNER_CONFIG[winner];

  return (
    <div
      className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/80 backdrop-blur-sm"
      style={{ opacity: visible ? 1 : 0, transition: "opacity 0.35s ease" }}
    >
      <div className="scanline-overlay" />

      {/* Winner announcement */}
      <div className="mb-5 text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <Swords size={18} style={{ color: cfg.color }} />
          <h2
            className="text-4xl font-black tracking-widest animate-neon-pulse"
            style={{ color: cfg.color, textShadow: `0 0 10px ${cfg.glow}, 0 0 30px ${cfg.glow}` }}
            data-testid="battle-winner"
          >
            {cfg.label}
          </h2>
          <Swords size={18} style={{ color: cfg.color }} />
        </div>
        <p className="text-xs text-muted-foreground tracking-widest">{cfg.sublabel}</p>
      </div>

      {/* Score comparison */}
      <div
        className="mb-6 border border-border/40 p-4 w-64"
        style={{ background: "rgba(0,0,0,0.5)" }}
        data-testid="battle-scoreboard"
      >
        <div className="flex justify-between items-center mb-2">
          <div className="text-xs tracking-widest font-bold" style={{ color: "#00ffff" }}>
            {winner === "p1" && <Trophy size={12} className="inline mr-1 text-yellow-400" />}
            P1
          </div>
          <div className="text-xs tracking-widest font-bold" style={{ color: "#ff44cc" }}>
            P2
            {winner === "p2" && <Trophy size={12} className="inline ml-1 text-yellow-400" />}
          </div>
        </div>
        <div className="flex justify-between items-center border-t border-border/20 pt-2">
          <div className="text-center">
            <div className="text-2xl font-black" style={{ color: "#00ffff" }}>{score1}</div>
            <div className="text-[10px] text-muted-foreground/60">分數</div>
          </div>
          <div className="text-[10px] text-muted-foreground/40 tracking-widest">VS</div>
          <div className="text-center">
            <div className="text-2xl font-black" style={{ color: "#ff44cc" }}>{score2}</div>
            <div className="text-[10px] text-muted-foreground/60">分數</div>
          </div>
        </div>
        <div className="flex justify-between items-center mt-1 text-[10px] text-muted-foreground/50 tracking-wider">
          <span>長度 {len1}</span>
          <span>長度 {len2}</span>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-3 w-52">
        <button
          onClick={onRestart}
          data-testid="button-battle-again"
          className="neon-btn flex items-center justify-center gap-2 py-3 px-6 border-2 font-bold text-sm tracking-widest transition-all"
          style={{
            borderColor: cfg.color,
            color: cfg.color,
            boxShadow: `0 0 8px ${cfg.glow}`,
          }}
        >
          <RotateCcw size={16} />
          再戰一局
        </button>
        <button
          onClick={onMenu}
          data-testid="button-battle-menu"
          className="neon-btn flex items-center justify-center gap-2 py-2 px-6 border border-muted-foreground/30 text-muted-foreground font-bold text-sm tracking-widest hover:border-muted-foreground/60 hover:text-foreground transition-all"
        >
          <Home size={14} />
          主選單
        </button>
      </div>
    </div>
  );
}
