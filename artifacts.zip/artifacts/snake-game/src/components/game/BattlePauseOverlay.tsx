import { Play, RotateCcw, Home } from "lucide-react";

interface BattlePauseOverlayProps {
  score1: number;
  score2: number;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}

export default function BattlePauseOverlay({ score1, score2, onResume, onRestart, onMenu }: BattlePauseOverlayProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/75 backdrop-blur-sm">
      <div className="scanline-overlay" />

      <div className="mb-6 text-center">
        <h2 className="text-5xl font-black tracking-widest neon-text-yellow animate-neon-pulse" data-testid="title-paused">
          暫停
        </h2>
        <p className="text-sm text-muted-foreground tracking-widest mt-2">PAUSED</p>
      </div>

      {/* Score comparison */}
      <div className="mb-8 flex items-center gap-6 text-base tracking-widest">
        <div className="text-center">
          <div className="text-xs mb-1" style={{ color: "rgba(0,255,255,0.55)" }}>P1 分數</div>
          <div className="font-black text-2xl" style={{ color: "#00ffff", textShadow: "0 0 8px #00ffff" }}>{score1}</div>
        </div>
        <div className="text-muted-foreground/30 text-lg font-black">VS</div>
        <div className="text-center">
          <div className="text-xs mb-1" style={{ color: "rgba(255,68,204,0.55)" }}>P2 分數</div>
          <div className="font-black text-2xl" style={{ color: "#ff44cc", textShadow: "0 0 8px #ff00cc" }}>{score2}</div>
        </div>
      </div>

      <div className="flex flex-col gap-3 w-60">
        <button onClick={onResume} data-testid="button-resume"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 neon-border-cyan text-primary font-bold text-base tracking-widest hover:bg-primary/10 transition-all">
          <Play size={18} fill="currentColor" /> 繼續對戰
        </button>
        <button onClick={onRestart} data-testid="button-restart"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 font-bold text-base tracking-widest transition-all"
          style={{ borderColor: "rgba(255,68,204,0.6)", color: "#ff44cc", boxShadow: "0 0 8px rgba(255,0,200,0.25)" }}>
          <RotateCcw size={18} /> 重新對戰
        </button>
        <button onClick={onMenu} data-testid="button-menu"
          className="neon-btn flex items-center justify-center gap-2 py-2.5 px-6 border border-muted-foreground/20 text-muted-foreground/60 font-bold text-sm tracking-widest hover:border-destructive/40 hover:text-destructive transition-all">
          <Home size={16} /> 主選單
        </button>
      </div>

      <p className="mt-6 text-sm text-muted-foreground/50 tracking-widest">按 ESC / P 繼續</p>
    </div>
  );
}
