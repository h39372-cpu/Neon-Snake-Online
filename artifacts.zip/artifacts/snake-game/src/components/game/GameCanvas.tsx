import { useEffect, useRef } from "react";
import type { Point, GameSettings, Item, ActiveEffects } from "@/hooks/useSnakeGame";
import { ITEM_CONFIG } from "@/hooks/useSnakeGame";

interface GameCanvasProps {
  snake: Point[];
  items: Item[];
  settings: GameSettings;
  activeEffects: ActiveEffects;
  tick: number;
}

const CELL_PAD = 1;

function drawRoundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export default function GameCanvas({ snake, items, settings, activeEffects: ae, tick }: GameCanvasProps) {
  const activeEffects = ae ?? { speed: 0, poison: 0, magnet: 0 };
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pulseRef  = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const { gridSize } = settings;
    const size = canvas.width;
    const cellSize = size / gridSize;

    pulseRef.current += 0.09;
    const pulse = Math.sin(pulseRef.current) * 0.3 + 0.7; // 0.4–1.0

    // ── Background ────────────────────────────────────────────────────────────
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "#050510";
    ctx.fillRect(0, 0, size, size);

    // ── Effect tints ──────────────────────────────────────────────────────────
    if (activeEffects.speed > 0) {
      ctx.fillStyle = "rgba(0,255,255,0.03)";
      ctx.fillRect(0, 0, size, size);
    }
    if (activeEffects.poison > 0) {
      ctx.fillStyle = "rgba(160,0,255,0.04)";
      ctx.fillRect(0, 0, size, size);
    }
    if (activeEffects.magnet > 0) {
      ctx.fillStyle = "rgba(255,150,0,0.03)";
      ctx.fillRect(0, 0, size, size);
    }

    // ── Grid ──────────────────────────────────────────────────────────────────
    ctx.strokeStyle = "rgba(0,255,255,0.055)";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= gridSize; i++) {
      const p = i * cellSize;
      ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, size); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(size, p); ctx.stroke();
    }

    // ── Items ─────────────────────────────────────────────────────────────────
    const fontSize = Math.max(8, Math.min(cellSize * 0.82, 24));
    ctx.font = `${fontSize}px serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (const item of items) {
      const cfg = ITEM_CONFIG[item.type];
      const cx = item.x * cellSize + cellSize / 2;
      const cy = item.y * cellSize + cellSize / 2;
      const r  = (cellSize / 2 - CELL_PAD) * pulse;

      // Glow halo
      ctx.shadowBlur = Math.max(10, cellSize * 1.5) * pulse;
      ctx.shadowColor = cfg.glow;
      ctx.fillStyle = cfg.glow + "55";
      ctx.beginPath();
      ctx.arc(cx, cy, r * 1.35, 0, Math.PI * 2);
      ctx.fill();

      // Core circle
      ctx.shadowBlur = Math.max(6, cellSize) * pulse;
      ctx.shadowColor = cfg.glow;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      grad.addColorStop(0, "#ffffff");
      grad.addColorStop(0.4, cfg.color);
      grad.addColorStop(1, cfg.glow);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Emoji label
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.fillText(cfg.emoji, cx, cy + 0.5);
    }

    ctx.shadowBlur = 0;

    // ── Snake ─────────────────────────────────────────────────────────────────
    const len = snake.length;

    // Determine head color tint based on active effects
    const headGlow = activeEffects.speed > 0
      ? "#88ffff"
      : activeEffects.poison > 0
        ? "#cc66ff"
        : "#00ffff";

    snake.forEach((seg, i) => {
      const x = seg.x * cellSize + CELL_PAD;
      const y = seg.y * cellSize + CELL_PAD;
      const w = cellSize - CELL_PAD * 2;
      const h = cellSize - CELL_PAD * 2;
      const r = Math.max(1.5, cellSize * 0.22);
      const t = i / Math.max(len - 1, 1);
      const brightness = 1 - t * 0.55;

      if (i === 0) {
        // Head
        ctx.shadowBlur = Math.max(10, cellSize * 1.6);
        ctx.shadowColor = headGlow;
        const hg = ctx.createLinearGradient(x, y, x + w, y + h);
        hg.addColorStop(0, `rgba(200,255,255,${brightness})`);
        hg.addColorStop(1, `rgba(0,210,210,${brightness})`);
        ctx.fillStyle = hg;
        drawRoundRect(ctx, x, y, w, h, r);
        ctx.fill();

        // Eyes
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#000022";
        const eyeR  = Math.max(0.8, cellSize * 0.08);
        const eyeOX = cellSize * 0.2;
        const eyeOY = cellSize * 0.18;
        const cx2 = seg.x * cellSize + cellSize / 2;
        const cy2 = seg.y * cellSize + cellSize / 2;
        ctx.beginPath();
        ctx.arc(cx2 - eyeOX, cy2 - eyeOY, eyeR, 0, Math.PI * 2);
        ctx.arc(cx2 + eyeOX, cy2 - eyeOY, eyeR, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Body — color shifts under effects
        let bodyR = 0, bodyG = 200, bodyB = 190;
        if (activeEffects.poison > 0) { bodyR = 120; bodyG = 50; bodyB = 200; }
        else if (activeEffects.speed > 0) { bodyR = 0; bodyG = 220; bodyB = 255; }

        ctx.shadowBlur = Math.max(4, cellSize * 0.7) * brightness;
        ctx.shadowColor = `rgba(${bodyR},${bodyG},${bodyB},${brightness * 0.8})`;
        const alt = i % 2 === 0;
        ctx.fillStyle = `rgba(${bodyR + (alt ? 10 : 0)},${bodyG - (alt ? 10 : 0)},${bodyB},${brightness})`;
        drawRoundRect(ctx, x, y, w, h, r);
        ctx.fill();

        if (cellSize > 9) {
          ctx.shadowBlur = 0;
          ctx.fillStyle = `rgba(180,255,255,${0.12 * brightness})`;
          drawRoundRect(ctx, x + 1, y + 1, w - 2, h * 0.35, r * 0.6);
          ctx.fill();
        }
      }
    });

    ctx.shadowBlur = 0;
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
  }, [snake, items, settings, activeEffects, tick]);

  const { gridSize } = settings;
  const canvasSize = Math.min(
    typeof window !== "undefined"
      ? Math.min(window.innerWidth - 32, window.innerHeight - 200)
      : 500,
    560
  );
  const snappedSize = Math.floor(canvasSize / gridSize) * gridSize;

  return (
    <canvas
      ref={canvasRef}
      width={snappedSize}
      height={snappedSize}
      className="block border-2 neon-border-cyan"
      style={{
        width: snappedSize,
        height: snappedSize,
        imageRendering: "pixelated",
        boxShadow: "0 0 30px rgba(0,255,255,0.25), 0 0 80px rgba(0,255,255,0.1)",
      }}
      data-testid="game-canvas"
    />
  );
}
