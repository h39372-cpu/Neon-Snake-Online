import { Pause, Music, VolumeX, Volume2, Music2 } from "lucide-react";
import type { GameSettings, ActiveEffects } from "@/hooks/useSnakeGame";

interface GameHUDProps {
  score: number;
  highScore: number;
  snakeLength: number;
  settings: GameSettings;
  activeEffects: ActiveEffects;
  onPause: () => void;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
}

interface EffectBadgeProps {
  emoji: string;
  ticks: number;
  color: string;
  label: string;
}

function EffectBadge({ emoji, ticks, color, label }: EffectBadgeProps) {
  return (
    <div
      className="flex items-center gap-1 px-2 py-0.5 text-xs font-bold tracking-wider"
      style={{ border: `1px solid ${color}55`, color, background: `${color}18` }}
      title={label}
      data-testid={`effect-badge-${label}`}
    >
      <span>{emoji}</span>
      <span>{ticks}</span>
    </div>
  );
}

export default function GameHUD({
  score, highScore, snakeLength, settings, activeEffects,
  onPause, onToggleMusic, onToggleSfx,
}: GameHUDProps) {
  const hasEffect = activeEffects.speed > 0 || activeEffects.poison > 0 || activeEffects.magnet > 0;

  return (
    <div className="w-full" data-testid="game-hud">
      {/* Main HUD row */}
      <div className="flex items-center justify-between px-1 py-2">
        {/* Scores */}
        <div className="flex gap-4 tracking-widest">
          <div data-testid="display-score">
            <div className="text-xs text-muted-foreground/60">分數</div>
            <div className="neon-text-cyan font-black text-xl leading-none">{score}</div>
          </div>
          <div data-testid="display-best">
            <div className="text-xs text-muted-foreground/60">最高</div>
            <div className="neon-text-yellow font-black text-xl leading-none">{highScore}</div>
          </div>
          <div data-testid="display-length">
            <div className="text-xs text-muted-foreground/60">長度</div>
            <div className="font-black text-xl leading-none text-foreground/70">{snakeLength}</div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          <button onClick={onToggleMusic} data-testid="hud-toggle-music"
            title={settings.musicEnabled ? "關閉音樂" : "開啟音樂"}
            className="p-1.5 transition-colors"
            style={{ color: settings.musicEnabled ? "#00ffff" : "rgba(150,150,170,0.5)" }}>
            {settings.musicEnabled ? <Music size={16} /> : <Music2 size={16} />}
          </button>
          <button onClick={onToggleSfx} data-testid="hud-toggle-sfx"
            title={settings.sfxEnabled ? "關閉音效" : "開啟音效"}
            className="p-1.5 transition-colors"
            style={{ color: settings.sfxEnabled ? "#bb00ff" : "rgba(150,150,170,0.5)" }}>
            {settings.sfxEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
          <button onClick={onPause} data-testid="button-pause"
            className="flex items-center gap-1.5 px-3 py-1.5 border text-sm font-bold tracking-widest transition-all hover:bg-primary/10"
            style={{ borderColor: "rgba(0,255,255,0.35)", color: "rgba(0,255,255,0.7)" }}>
            <Pause size={13} /> 暫停
          </button>
        </div>
      </div>

      {/* Active effects bar */}
      {hasEffect && (
        <div className="flex items-center gap-2 px-1 pb-1.5" data-testid="effects-bar">
          <span className="text-xs text-muted-foreground/40 tracking-widest">效果</span>
          {activeEffects.speed > 0 && (
            <EffectBadge emoji="⚡" ticks={activeEffects.speed} color="#00ffff" label="加速" />
          )}
          {activeEffects.poison > 0 && (
            <EffectBadge emoji="💜" ticks={activeEffects.poison} color="#cc44ff" label="毒藥" />
          )}
          {activeEffects.magnet > 0 && (
            <EffectBadge emoji="🧲" ticks={activeEffects.magnet} color="#ff9900" label="磁鐵" />
          )}
        </div>
      )}
    </div>
  );
}
