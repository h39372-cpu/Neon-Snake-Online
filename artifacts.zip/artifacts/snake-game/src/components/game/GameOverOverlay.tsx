import { RotateCcw, Home, Trophy } from "lucide-react";
import { useEffect, useState } from "react";

interface GameOverOverlayProps {
  score: number;
  highScore: number;
  snakeLength: number;
  isNewHighScore: boolean;
  onRestart: () => void;
  onMenu: () => void;
}

export default function GameOverOverlay({
  score, highScore, snakeLength, isNewHighScore, onRestart, onMenu,
}: GameOverOverlayProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 200);
    return () => clearTimeout(t);
  }, []);

  return (
    <div
      className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/80 backdrop-blur-sm"
      style={{ opacity: visible ? 1 : 0, transition: "opacity 0.4s ease" }}
    >
      <div className="scanline-overlay" />

      {/* Title */}
      <div className="mb-6 text-center">
        <h2
          className="text-5xl sm:text-6xl font-black tracking-widest"
          style={{ color: "#ff3333", textShadow: "0 0 10px #ff0000, 0 0 25px #ff0000, 0 0 50px #ff0000" }}
          data-testid="title-game-over"
        >
          遊戲結束
        </h2>
        <p className="text-sm text-muted-foreground tracking-widest mt-1">GAME OVER</p>
      </div>

      {/* New high score badge */}
      {isNewHighScore && (
        <div
          className="mb-4 px-4 py-1.5 text-sm font-bold tracking-widest animate-neon-pulse"
          style={{ color: "#ffff00", textShadow: "0 0 8px #ffff00", border: "1px solid rgba(255,255,0,0.4)" }}
          data-testid="badge-new-highscore"
        >
          NEW HIGH SCORE!
        </div>
      )}

      {/* Score card */}
      <div
        className="mb-8 border border-border/50 p-6 text-center space-y-3 min-w-52"
        style={{ background: "rgba(0,0,0,0.5)" }}
        data-testid="scoreboard"
      >
        <div>
          <div className="text-sm text-muted-foreground tracking-widest mb-1">本局分數</div>
          <div className="text-4xl font-black neon-text-cyan" data-testid="display-final-score">
            {score}
          </div>
        </div>

        <div className="border-t border-border/30 pt-3 flex items-center justify-center gap-2">
          <Trophy size={14} className="text-yellow-400" />
          <span className="text-sm text-muted-foreground tracking-widest">最高分</span>
          <span className="neon-text-yellow text-base font-bold" data-testid="display-highscore-go">
            {highScore}
          </span>
        </div>

        <div className="text-sm text-muted-foreground/60 tracking-wider">
          蛇的長度 {snakeLength}
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-3 w-60">
        <button
          onClick={onRestart}
          data-testid="button-play-again"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 neon-border-cyan text-primary font-bold text-base tracking-widest hover:bg-primary/10 transition-all"
        >
          <RotateCcw size={18} />
          再玩一次
        </button>

        <button
          onClick={onMenu}
          data-testid="button-main-menu"
          className="neon-btn flex items-center justify-center gap-2 py-2.5 px-6 border border-muted-foreground/30 text-muted-foreground font-bold text-sm tracking-widest hover:border-muted-foreground/60 hover:text-foreground transition-all"
        >
          <Home size={16} />
          主選單
        </button>
      </div>
    </div>
  );
}
