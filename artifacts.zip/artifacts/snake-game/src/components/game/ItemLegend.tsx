import type { ActiveEffects, ItemType } from "@/hooks/useSnakeGame";

interface LegendEntry {
  type: ItemType;
  emoji: string;
  name: string;
  desc: string;
  color: string;
  glow: string;
  activeKey?: keyof ActiveEffects;
}

const ENTRIES: LegendEntry[] = [
  { type: "food",    emoji: "🍎", name: "普通食物", desc: "+1 分",     color: "#ff5555", glow: "#ff2222" },
  { type: "star",    emoji: "⭐", name: "特殊食物", desc: "+3 分",     color: "#ffee44", glow: "#ffcc00" },
  { type: "gold",    emoji: "🏅", name: "黃金食物", desc: "+10 分",    color: "#ffaa00", glow: "#ff7700" },
  { type: "speed",   emoji: "⚡", name: "加速道具", desc: "速度 ×2",   color: "#00ffff", glow: "#00ccff", activeKey: "speed"  },
  { type: "shorten", emoji: "🔵", name: "縮短道具", desc: "縮短+2分",  color: "#0099ff", glow: "#0055ff" },
  { type: "poison",  emoji: "💜", name: "毒藥道具", desc: "縮短·減速", color: "#cc44ff", glow: "#aa00ff", activeKey: "poison" },
  { type: "magnet",  emoji: "🧲", name: "磁鐵道具", desc: "吸引食物",  color: "#ff9900", glow: "#ff6600", activeKey: "magnet" },
];

interface ItemLegendProps {
  activeEffects: ActiveEffects;
}

export default function ItemLegend({ activeEffects }: ItemLegendProps) {
  return (
    <div className="flex flex-col gap-1.5 select-none" data-testid="item-legend" style={{ minWidth: 130 }}>
      <div
        className="text-xs font-bold tracking-[0.2em] mb-1 pb-1.5"
        style={{ color: "rgba(0,255,255,0.5)", borderBottom: "1px solid rgba(0,255,255,0.14)" }}
      >
        道具圖例
      </div>

      {ENTRIES.map(({ type, emoji, name, desc, color, glow, activeKey }) => {
        const isActive = activeKey ? activeEffects[activeKey] > 0 : false;
        const ticks    = activeKey ? activeEffects[activeKey] : 0;

        return (
          <div
            key={type}
            className="flex items-center gap-2 px-2 py-1.5 transition-all"
            style={{
              background: isActive ? `${color}18` : "rgba(255,255,255,0.025)",
              border: `1px solid ${isActive ? color + "60" : "rgba(255,255,255,0.07)"}`,
              borderRadius: 4,
              boxShadow: isActive ? `0 0 10px ${glow}44` : "none",
            }}
          >
            {/* Emoji */}
            <span style={{ fontSize: 17, lineHeight: 1 }}>{emoji}</span>

            {/* Text */}
            <div className="flex flex-col min-w-0">
              <span
                className="text-xs font-bold leading-tight"
                style={{ color: isActive ? color : "rgba(255,255,255,0.75)" }}
              >
                {name}
              </span>
              <span
                className="text-[11px] leading-tight"
                style={{ color: isActive ? color + "cc" : "rgba(255,255,255,0.35)" }}
              >
                {isActive && ticks > 0 ? `剩餘 ${ticks} tick` : desc}
              </span>
            </div>

            {/* Active pulse dot */}
            {isActive && (
              <div
                className="ml-auto shrink-0 rounded-full animate-pulse"
                style={{ width: 6, height: 6, background: color, boxShadow: `0 0 6px ${glow}` }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
