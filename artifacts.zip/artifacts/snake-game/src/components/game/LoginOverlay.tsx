import { useLocation } from "wouter";
import { UserCircle2 } from "lucide-react";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

interface LoginOverlayProps {
  onGuest: () => void;
}

export default function LoginOverlay({ onGuest }: LoginOverlayProps) {
  const [, navigate] = useLocation();

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/70 backdrop-blur-sm overflow-y-auto py-6">
      <div className="scanline-overlay" />

      {/* Title */}
      <div className="mb-6 text-center animate-flicker flex-shrink-0">
        <h1 className="text-5xl sm:text-6xl font-black tracking-widest neon-text-cyan mb-1">NEON</h1>
        <h1 className="text-5xl sm:text-6xl font-black tracking-widest neon-text-magenta">SNAKE</h1>
      </div>

      {/* Login card */}
      <div
        className="flex flex-col gap-2.5 mb-5 flex-shrink-0"
        style={{
          width: 272,
          border: "1px solid rgba(0,255,255,0.15)",
          padding: "20px 20px",
          background: "rgba(5,5,20,0.9)",
          boxShadow: "0 0 30px rgba(0,255,255,0.07)",
        }}
      >
        <p className="text-center text-[10px] text-muted-foreground tracking-widest mb-1 uppercase">
          登入以儲存分數
        </p>

        {/* Email sign-in */}
        <button
          onClick={() => navigate("/sign-in")}
          className="flex items-center justify-center gap-2.5 py-2.5 px-5 font-bold text-xs tracking-wide transition-all border"
          style={{
            borderColor: "rgba(0,255,255,0.3)",
            color: "#00ffff",
            background: "rgba(0,255,255,0.05)",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background = "rgba(0,255,255,0.12)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background = "rgba(0,255,255,0.05)";
          }}
        >
          <UserCircle2 size={15} />
          電子郵件登入 / 註冊
        </button>

        {/* Guest divider */}
        <div className="flex items-center gap-2 mt-0.5">
          <div className="flex-1 border-t border-muted/20" />
          <span className="text-[10px] text-muted-foreground/40 tracking-widest">或</span>
          <div className="flex-1 border-t border-muted/20" />
        </div>

        {/* Guest */}
        <button
          onClick={onGuest}
          className="flex items-center justify-center gap-2 py-2 px-5 text-[11px] font-bold tracking-widest transition-all border"
          style={{
            borderColor: "rgba(255,255,255,0.1)",
            color: "rgba(255,255,255,0.4)",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.color = "rgba(255,255,255,0.7)";
            (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.25)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.color = "rgba(255,255,255,0.4)";
            (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.1)";
          }}
        >
          訪客遊玩（不儲存分數）
        </button>
      </div>

      {/* Animated snake decoration */}
      <div className="flex gap-1.5 opacity-30 flex-shrink-0">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="w-3 h-3 rounded-sm"
            style={{
              background: i === 0 ? "#00ffff" : `rgba(0,${180 - i * 15},${180 - i * 15},1)`,
              boxShadow: i === 0 ? "0 0 6px #00ffff" : undefined,
            }}
          />
        ))}
      </div>
    </div>
  );
}
