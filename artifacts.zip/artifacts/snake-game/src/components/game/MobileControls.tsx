import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import type { Direction } from "@/hooks/useSnakeGame";
import { useRef } from "react";

interface MobileControlsProps {
  onDirection: (dir: Direction) => void;
}

export default function MobileControls({ onDirection }: MobileControlsProps) {
  const lastDirRef = useRef<Direction | null>(null);

  const press = (dir: Direction) => {
    const opposite: Record<Direction, Direction> = {
      UP: "DOWN", DOWN: "UP", LEFT: "RIGHT", RIGHT: "LEFT",
    };
    if (lastDirRef.current && opposite[lastDirRef.current] === dir) return;
    lastDirRef.current = dir;
    onDirection(dir);
  };

  const btnStyle = (color: string) => ({
    background: `rgba(${color}, 0.08)`,
    border: `1px solid rgba(${color}, 0.3)`,
    boxShadow: `0 0 6px rgba(${color}, 0.15)`,
  });

  const btnClass =
    "flex items-center justify-center w-12 h-12 active:scale-95 transition-transform select-none touch-none";

  const c = "0,255,255";

  return (
    <div className="flex flex-col items-center gap-1 mt-3" data-testid="mobile-controls">
      <button
        className={btnClass}
        style={btnStyle(c)}
        onPointerDown={() => press("UP")}
        data-testid="mobile-up"
      >
        <ChevronUp size={22} style={{ color: "#00ffff" }} />
      </button>
      <div className="flex gap-1">
        <button
          className={btnClass}
          style={btnStyle(c)}
          onPointerDown={() => press("LEFT")}
          data-testid="mobile-left"
        >
          <ChevronLeft size={22} style={{ color: "#00ffff" }} />
        </button>
        <button
          className={btnClass}
          style={btnStyle(c)}
          onPointerDown={() => press("DOWN")}
          data-testid="mobile-down"
        >
          <ChevronDown size={22} style={{ color: "#00ffff" }} />
        </button>
        <button
          className={btnClass}
          style={btnStyle(c)}
          onPointerDown={() => press("RIGHT")}
          data-testid="mobile-right"
        >
          <ChevronRight size={22} style={{ color: "#00ffff" }} />
        </button>
      </div>
    </div>
  );
}
