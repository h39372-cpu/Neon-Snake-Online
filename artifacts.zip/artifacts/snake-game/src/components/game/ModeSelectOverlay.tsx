import { User, Swords, Zap, Skull, Trophy, Settings, LogOut } from "lucide-react";
import { useUser } from "@clerk/react";
import type { BattleRule } from "@/hooks/useBattleGame";

interface ModeSelectOverlayProps {
  highScore: number;
  onSolo: () => void;
  onBattle: (rule: BattleRule) => void;
  onSettings: () => void;
  onSignOut: () => void;
  isGuest: boolean;
}

export default function ModeSelectOverlay({
  highScore, onSolo, onBattle, onSettings, onSignOut, isGuest,
}: ModeSelectOverlayProps) {
  const { user } = useUser();

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/70 backdrop-blur-sm">
      <div className="scanline-overlay" />

      {/* Title */}
      <div className="mb-6 text-center animate-flicker">
        <h1 className="text-5xl sm:text-6xl font-black tracking-widest neon-text-cyan mb-1">NEON</h1>
        <h1 className="text-5xl sm:text-6xl font-black tracking-widest neon-text-magenta">SNAKE</h1>
      </div>

      {/* User info */}
      <div className="mb-4 flex items-center gap-2 text-xs tracking-widest">
        {isGuest ? (
          <span className="text-muted-foreground/60">訪客模式</span>
        ) : (
          <>
            {user?.imageUrl && (
              <img src={user.imageUrl} alt="" className="w-5 h-5 rounded-full border border-cyan-900/50" />
            )}
            <span className="text-cyan-400/80">{user?.firstName ?? user?.emailAddresses?.[0]?.emailAddress ?? "玩家"}</span>
          </>
        )}
      </div>

      <div className="mb-4 flex items-center gap-2 text-sm tracking-widest">
        <Trophy size={13} className="text-yellow-400" />
        <span className="text-muted-foreground">最高分</span>
        <span className="neon-text-yellow font-bold">{highScore}</span>
      </div>

      {/* Mode buttons */}
      <div className="flex flex-col gap-3 w-64">

        {/* Solo */}
        <button
          onClick={onSolo}
          data-testid="button-mode-solo"
          className="neon-btn flex items-center gap-3 py-3 px-5 border-2 neon-border-cyan text-primary font-bold text-sm tracking-wider hover:bg-primary/10 transition-all"
        >
          <User size={18} />
          <div className="text-left">
            <div>單人模式</div>
            <div className="text-[10px] font-normal text-primary/60 tracking-normal">SINGLE PLAYER</div>
          </div>
        </button>

        {/* Battle divider */}
        <div className="flex items-center gap-2 mt-1">
          <div className="flex-1 border-t border-muted/30" />
          <span className="text-[10px] text-muted-foreground/50 tracking-widest flex items-center gap-1">
            <Swords size={10} /> 雙人對戰
          </span>
          <div className="flex-1 border-t border-muted/30" />
        </div>

        {/* Elimination */}
        <button
          onClick={() => onBattle("elimination")}
          data-testid="button-mode-elimination"
          className="neon-btn flex items-center gap-3 py-3 px-5 border-2 font-bold text-sm tracking-wider transition-all"
          style={{
            borderColor: "rgba(255,0,200,0.6)",
            color: "#ff44cc",
            boxShadow: "0 0 8px rgba(255,0,200,0.2)",
          }}
        >
          <Skull size={18} />
          <div className="text-left">
            <div>致命模式</div>
            <div className="text-[10px] font-normal opacity-60 tracking-normal">
              撞到對手即淘汰
            </div>
          </div>
        </button>

        {/* Absorption */}
        <button
          onClick={() => onBattle("absorption")}
          data-testid="button-mode-absorption"
          className="neon-btn flex items-center gap-3 py-3 px-5 border-2 font-bold text-sm tracking-wider transition-all"
          style={{
            borderColor: "rgba(255,160,0,0.6)",
            color: "#ffaa00",
            boxShadow: "0 0 8px rgba(255,160,0,0.2)",
          }}
        >
          <Zap size={18} />
          <div className="text-left">
            <div>吞噬模式</div>
            <div className="text-[10px] font-normal opacity-60 tracking-normal">
              吃到對手身體即增大
            </div>
          </div>
        </button>

        {/* Settings */}
        <button
          onClick={onSettings}
          data-testid="button-mode-settings"
          className="neon-btn flex items-center justify-center gap-2 py-2 px-5 border border-muted/30 text-muted-foreground text-xs font-bold tracking-wider hover:border-muted/60 hover:text-foreground transition-all mt-1"
        >
          <Settings size={13} />
          遊戲設定
        </button>

        {/* Sign out */}
        <button
          onClick={onSignOut}
          className="flex items-center justify-center gap-2 py-1.5 px-5 text-[10px] font-bold tracking-widest text-muted-foreground/30 hover:text-muted-foreground/60 transition-all"
        >
          <LogOut size={11} />
          {isGuest ? "切換帳號" : "登出"}
        </button>
      </div>

      {/* Controls legend */}
      <div className="mt-4 flex gap-6 text-[10px] text-muted-foreground/40 tracking-widest">
        <div>
          <span style={{ color: "rgba(0,255,255,0.5)" }}>P1</span>
          {" "}WASD
        </div>
        <div>
          <span style={{ color: "rgba(255,0,200,0.5)" }}>P2</span>
          {" "}方向鍵
        </div>
      </div>
    </div>
  );
}
