import { Play, RotateCcw, Settings, Home } from "lucide-react";

interface PauseOverlayProps {
  score: number;
  onResume: () => void;
  onRestart: () => void;
  onSettings: () => void;
  onMenu: () => void;
}

export default function PauseOverlay({
  score, onResume, onRestart, onSettings, onMenu,
}: PauseOverlayProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/75 backdrop-blur-sm">
      <div className="scanline-overlay" />

      {/* Title */}
      <div className="mb-6 text-center">
        <h2
          className="text-5xl font-black tracking-widest neon-text-yellow animate-neon-pulse"
          data-testid="title-paused"
        >
          暫停
        </h2>
        <p className="text-sm text-muted-foreground tracking-widest mt-2">PAUSED</p>
      </div>

      {/* Current score */}
      <div
        className="mb-8 px-6 py-2.5 border border-border/40 text-base tracking-widest"
        data-testid="display-score-paused"
      >
        <span className="text-muted-foreground">當前分數 </span>
        <span className="neon-text-cyan font-bold">{score}</span>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-3 w-60">
        <button
          onClick={onResume}
          data-testid="button-resume"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 neon-border-cyan text-primary font-bold text-base tracking-widest hover:bg-primary/10 transition-all"
        >
          <Play size={18} fill="currentColor" />
          繼續遊戲
        </button>

        <button
          onClick={onRestart}
          data-testid="button-restart"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 border-secondary/60 text-secondary font-bold text-base tracking-widest hover:bg-secondary/10 transition-all"
          style={{ boxShadow: "0 0 8px rgba(180,0,255,0.3)" }}
        >
          <RotateCcw size={18} />
          重新開始
        </button>

        <button
          onClick={onSettings}
          data-testid="button-settings-paused"
          className="neon-btn flex items-center justify-center gap-2 py-2.5 px-6 border border-muted-foreground/30 text-muted-foreground font-bold text-sm tracking-widest hover:border-muted-foreground/60 hover:text-foreground transition-all"
        >
          <Settings size={16} />
          遊戲設定
        </button>

        <button
          onClick={onMenu}
          data-testid="button-menu"
          className="neon-btn flex items-center justify-center gap-2 py-2.5 px-6 border border-muted-foreground/20 text-muted-foreground/60 font-bold text-sm tracking-widest hover:border-destructive/40 hover:text-destructive transition-all"
        >
          <Home size={16} />
          主選單
        </button>
      </div>

      <p className="mt-6 text-sm text-muted-foreground/50 tracking-widest">
        按 ESC / P 繼續
      </p>
    </div>
  );
}
