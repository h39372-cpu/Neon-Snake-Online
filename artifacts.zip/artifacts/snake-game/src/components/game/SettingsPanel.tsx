import { X, Volume2, VolumeX, Music, Music2 } from "lucide-react";
import type { GameSettings, Speed } from "@/hooks/useSnakeGame";

interface SettingsPanelProps {
  settings: GameSettings;
  onUpdate: (partial: Partial<GameSettings>) => void;
  onClose: () => void;
}

const SPEEDS: { value: Speed; label: string; sublabel: string }[] = [
  { value: "slow",   label: "慢速", sublabel: "SLOW"   },
  { value: "normal", label: "正常", sublabel: "NORMAL" },
  { value: "fast",   label: "快速", sublabel: "FAST"   },
];

const GRID_SIZES = [
  { value: 20, label: "小  20×20" },
  { value: 35, label: "中  35×35" },
  { value: 50, label: "大  50×50" },
];

export default function SettingsPanel({ settings, onUpdate, onClose }: SettingsPanelProps) {
  return (
    <div className="absolute inset-0 flex items-center justify-center z-30 bg-black/80 backdrop-blur-sm">
      <div className="scanline-overlay" />

      <div
        className="relative border-2 neon-border-cyan p-6 w-84 max-w-[92vw]"
        style={{ background: "rgba(5,5,20,0.95)", width: 340 }}
        data-testid="settings-panel"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-black tracking-widest neon-text-cyan" data-testid="title-settings">
            遊戲設定
          </h3>
          <button
            onClick={onClose}
            data-testid="button-close-settings"
            className="p-1 text-muted-foreground hover:text-primary transition-colors"
          >
            <X size={22} />
          </button>
        </div>

        {/* Speed */}
        <div className="mb-6">
          <label className="block text-sm text-muted-foreground tracking-widest mb-3">
            遊戲速度
          </label>
          <div className="grid grid-cols-3 gap-2">
            {SPEEDS.map((s) => (
              <button
                key={s.value}
                onClick={() => onUpdate({ speed: s.value })}
                data-testid={`button-speed-${s.value}`}
                className="py-2.5 px-2 border text-sm font-bold tracking-wider transition-all"
                style={
                  settings.speed === s.value
                    ? { borderColor: "#00ffff", color: "#00ffff", background: "rgba(0,255,255,0.1)", boxShadow: "0 0 8px rgba(0,255,255,0.3)" }
                    : { borderColor: "rgba(0,255,255,0.2)", color: "rgba(0,255,255,0.45)" }
                }
              >
                <div>{s.label}</div>
                <div className="opacity-60 text-xs">{s.sublabel}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Grid size */}
        <div className="mb-6">
          <label className="block text-sm text-muted-foreground tracking-widest mb-3">
            地圖大小
          </label>
          <div className="space-y-2">
            {GRID_SIZES.map((g) => (
              <button
                key={g.value}
                onClick={() => onUpdate({ gridSize: g.value })}
                data-testid={`button-grid-${g.value}`}
                className="w-full py-2.5 px-3 border text-sm font-bold tracking-wider text-left transition-all"
                style={
                  settings.gridSize === g.value
                    ? { borderColor: "#bb00ff", color: "#dd88ff", background: "rgba(180,0,255,0.1)", boxShadow: "0 0 8px rgba(180,0,255,0.3)" }
                    : { borderColor: "rgba(180,0,255,0.2)", color: "rgba(180,0,255,0.45)" }
                }
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* Audio toggles */}
        <div className="space-y-4 border-t border-border/30 pt-5">
          {/* Music */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm tracking-widest text-muted-foreground">
              {settings.musicEnabled ? <Music size={16} className="text-primary" /> : <Music2 size={16} />}
              <span>背景音樂</span>
            </div>
            <button
              onClick={() => onUpdate({ musicEnabled: !settings.musicEnabled })}
              data-testid="toggle-music"
              className="relative w-11 h-6 transition-all"
              style={{
                background: settings.musicEnabled ? "rgba(0,255,255,0.2)" : "rgba(100,100,120,0.2)",
                border: `1px solid ${settings.musicEnabled ? "#00ffff" : "rgba(100,100,120,0.4)"}`,
                boxShadow: settings.musicEnabled ? "0 0 6px rgba(0,255,255,0.4)" : undefined,
                borderRadius: 4,
              }}
            >
              <div
                className="absolute top-0.5 w-4 h-4 transition-all"
                style={{
                  left: settings.musicEnabled ? "calc(100% - 1.2rem)" : "2px",
                  background: settings.musicEnabled ? "#00ffff" : "rgba(150,150,170,0.8)",
                  boxShadow: settings.musicEnabled ? "0 0 6px #00ffff" : undefined,
                  borderRadius: 2,
                }}
              />
            </button>
          </div>

          {/* SFX */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm tracking-widest text-muted-foreground">
              {settings.sfxEnabled ? <Volume2 size={16} className="text-secondary" /> : <VolumeX size={16} />}
              <span>音效</span>
            </div>
            <button
              onClick={() => onUpdate({ sfxEnabled: !settings.sfxEnabled })}
              data-testid="toggle-sfx"
              className="relative w-11 h-6 transition-all"
              style={{
                background: settings.sfxEnabled ? "rgba(180,0,255,0.2)" : "rgba(100,100,120,0.2)",
                border: `1px solid ${settings.sfxEnabled ? "#bb00ff" : "rgba(100,100,120,0.4)"}`,
                boxShadow: settings.sfxEnabled ? "0 0 6px rgba(180,0,255,0.4)" : undefined,
                borderRadius: 4,
              }}
            >
              <div
                className="absolute top-0.5 w-4 h-4 transition-all"
                style={{
                  left: settings.sfxEnabled ? "calc(100% - 1.2rem)" : "2px",
                  background: settings.sfxEnabled ? "#dd88ff" : "rgba(150,150,170,0.8)",
                  boxShadow: settings.sfxEnabled ? "0 0 6px #bb00ff" : undefined,
                  borderRadius: 2,
                }}
              />
            </button>
          </div>
        </div>

        <div className="mt-5 text-xs text-muted-foreground/40 tracking-widest text-center">
          設定在下次開始遊戲時生效
        </div>
      </div>
    </div>
  );
}
