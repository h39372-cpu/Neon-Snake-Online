import { Play, Trophy, Settings } from "lucide-react";

interface StartOverlayProps {
  highScore: number;
  onStart: () => void;
  onSettings: () => void;
}

export default function StartOverlay({ highScore, onStart, onSettings }: StartOverlayProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/70 backdrop-blur-sm">
      <div className="scanline-overlay" />

      {/* Title */}
      <div className="mb-8 text-center animate-flicker">
        <h1
          className="text-6xl sm:text-7xl font-black tracking-widest neon-text-cyan mb-1"
          data-testid="title-neon-snake"
        >
          NEON
        </h1>
        <h1 className="text-6xl sm:text-7xl font-black tracking-widest neon-text-magenta">
          SNAKE
        </h1>
      </div>

      {/* High score */}
      <div
        className="mb-8 flex items-center gap-2 text-base tracking-widest"
        data-testid="display-highscore"
      >
        <Trophy size={16} className="text-yellow-400" />
        <span className="text-muted-foreground">最高分</span>
        <span className="neon-text-yellow font-bold">{highScore}</span>
      </div>

      {/* Controls hint */}
      <div className="mb-8 text-sm text-muted-foreground tracking-wider text-center space-y-1.5">
        <p>方向鍵 / WASD 移動蛇</p>
        <p>ESC / P 暫停遊戲</p>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-3 w-60">
        <button
          onClick={onStart}
          data-testid="button-start-game"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 neon-border-cyan text-primary font-bold text-base tracking-widest hover:bg-primary/10 transition-all"
        >
          <Play size={18} fill="currentColor" />
          開始遊戲
        </button>

        <button
          onClick={onSettings}
          data-testid="button-settings"
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 border-secondary/60 text-secondary font-bold text-base tracking-widest hover:bg-secondary/10 transition-all"
          style={{ boxShadow: "0 0 8px rgba(180,0,255,0.3)" }}
        >
          <Settings size={18} />
          遊戲設定
        </button>
      </div>

      {/* Animated snake decoration */}
      <div className="mt-10 flex gap-1.5 opacity-40">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="w-3.5 h-3.5 rounded-sm"
            style={{
              background: i === 0 ? "#00ffff" : `rgba(0,${180 - i * 15},${180 - i * 15},1)`,
              boxShadow: i === 0 ? "0 0 6px #00ffff" : undefined,
            }}
          />
        ))}
      </div>
    </div>
  );
}
