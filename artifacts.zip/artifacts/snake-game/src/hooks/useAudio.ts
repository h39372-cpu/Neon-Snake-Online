import { useRef, useEffect, useCallback } from "react";

// Neon Snake chiptune — C minor pentatonic melody + bassline
// All audio synthesized in-browser via Web Audio API (no files needed)

const MELODY: number[] = [
  523, 659, 784, 659,   523, 440, 349, 440,
  523, 659, 784, 1047,  784, 659, 523, 440,
  349, 440, 523, 659,   523, 440, 349, 294,
  349, 440, 523, 659,   784, 659, 523, 440,
];

const BASS: number[] = [
  131, 131, 165, 131,
  110, 110, 131, 110,
  87,  87,  110, 87,
  110, 110, 131, 110,
];

const BEAT_MS = 140;

export function useAudio(musicEnabled: boolean, sfxEnabled: boolean) {
  const ctxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const musicIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const melodyStepRef = useRef(0);
  const bassStepRef = useRef(0);
  const musicEnabledRef = useRef(musicEnabled);
  const sfxEnabledRef = useRef(sfxEnabled);

  useEffect(() => { musicEnabledRef.current = musicEnabled; }, [musicEnabled]);
  useEffect(() => { sfxEnabledRef.current = sfxEnabled; }, [sfxEnabled]);

  const getCtx = useCallback((): AudioContext => {
    if (!ctxRef.current || ctxRef.current.state === "closed") {
      ctxRef.current = new (window.AudioContext ||
        (window as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext!)();
    }
    if (ctxRef.current.state === "suspended") {
      ctxRef.current.resume();
    }
    if (!masterGainRef.current || masterGainRef.current.context !== ctxRef.current) {
      const g = ctxRef.current.createGain();
      g.gain.value = 0.7;
      g.connect(ctxRef.current.destination);
      masterGainRef.current = g;
    }
    return ctxRef.current;
  }, []);

  const playTone = useCallback(
    (
      freq: number,
      duration: number,
      volume: number,
      type: OscillatorType = "square",
      startDelay = 0
    ) => {
      try {
        const ctx = getCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, ctx.currentTime + startDelay);
        gain.gain.setValueAtTime(0, ctx.currentTime + startDelay);
        gain.gain.linearRampToValueAtTime(
          volume,
          ctx.currentTime + startDelay + 0.01
        );
        gain.gain.exponentialRampToValueAtTime(
          0.001,
          ctx.currentTime + startDelay + duration
        );
        osc.connect(gain);
        gain.connect(masterGainRef.current!);
        osc.start(ctx.currentTime + startDelay);
        osc.stop(ctx.currentTime + startDelay + duration);
      } catch {
        // Silently ignore audio errors
      }
    },
    [getCtx]
  );

  // Sound effects
  const playEat = useCallback(() => {
    if (!sfxEnabledRef.current) return;
    playTone(880, 0.08, 0.18, "square");
    playTone(1320, 0.07, 0.12, "square", 0.06);
  }, [playTone]);

  const playDie = useCallback(() => {
    if (!sfxEnabledRef.current) return;
    [440, 330, 220, 110].forEach((freq, i) => {
      playTone(freq, 0.2, 0.25, "sawtooth", i * 0.1);
    });
  }, [playTone]);

  const playPause = useCallback(() => {
    if (!sfxEnabledRef.current) return;
    playTone(660, 0.06, 0.1, "square");
    playTone(440, 0.08, 0.08, "square", 0.07);
  }, [playTone]);

  const playResume = useCallback(() => {
    if (!sfxEnabledRef.current) return;
    playTone(440, 0.06, 0.08, "square");
    playTone(660, 0.08, 0.12, "square", 0.07);
  }, [playTone]);

  // Background music loop
  const startMusic = useCallback(() => {
    if (musicIntervalRef.current) return;

    // Ensure audio context is alive
    getCtx();

    let beat = 0;
    musicIntervalRef.current = setInterval(() => {
      if (!musicEnabledRef.current) return;

      try {
        const ctx = getCtx();
        if (!masterGainRef.current) return;

        // Melody note (every beat)
        const mFreq = MELODY[melodyStepRef.current % MELODY.length];
        const mOsc = ctx.createOscillator();
        const mGain = ctx.createGain();
        mOsc.type = "square";
        mOsc.frequency.setValueAtTime(mFreq, ctx.currentTime);
        mGain.gain.setValueAtTime(0.07, ctx.currentTime);
        mGain.gain.exponentialRampToValueAtTime(
          0.001,
          ctx.currentTime + (BEAT_MS / 1000) * 0.85
        );
        mOsc.connect(mGain);
        mGain.connect(masterGainRef.current);
        mOsc.start(ctx.currentTime);
        mOsc.stop(ctx.currentTime + (BEAT_MS / 1000) * 0.9);
        melodyStepRef.current++;

        // Bass every 4 beats
        if (beat % 4 === 0) {
          const bFreq = BASS[bassStepRef.current % BASS.length];
          const bOsc = ctx.createOscillator();
          const bGain = ctx.createGain();
          bOsc.type = "triangle";
          bOsc.frequency.setValueAtTime(bFreq, ctx.currentTime);
          bGain.gain.setValueAtTime(0.12, ctx.currentTime);
          bGain.gain.exponentialRampToValueAtTime(
            0.001,
            ctx.currentTime + (BEAT_MS / 1000) * 3.5
          );
          bOsc.connect(bGain);
          bGain.connect(masterGainRef.current);
          bOsc.start(ctx.currentTime);
          bOsc.stop(ctx.currentTime + (BEAT_MS / 1000) * 4);
          bassStepRef.current++;
        }

        // Hi-hat on every other beat
        if (beat % 2 === 0) {
          const noiseOsc = ctx.createOscillator();
          const noiseGain = ctx.createGain();
          noiseOsc.type = "sawtooth";
          noiseOsc.frequency.setValueAtTime(8000 + Math.random() * 4000, ctx.currentTime);
          noiseGain.gain.setValueAtTime(0.015, ctx.currentTime);
          noiseGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
          noiseOsc.connect(noiseGain);
          noiseGain.connect(masterGainRef.current);
          noiseOsc.start(ctx.currentTime);
          noiseOsc.stop(ctx.currentTime + 0.04);
        }

        beat++;
      } catch {
        // Ignore
      }
    }, BEAT_MS);
  }, [getCtx]);

  const stopMusic = useCallback(() => {
    if (musicIntervalRef.current) {
      clearInterval(musicIntervalRef.current);
      musicIntervalRef.current = null;
    }
    // Reset steps so music restarts from beginning
    melodyStepRef.current = 0;
    bassStepRef.current = 0;
  }, []);

  // React to musicEnabled changes
  useEffect(() => {
    if (musicEnabled) {
      startMusic();
    } else {
      stopMusic();
    }
  }, [musicEnabled, startMusic, stopMusic]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopMusic();
      ctxRef.current?.close();
    };
  }, [stopMusic]);

  return { playEat, playDie, playPause, playResume, startMusic, stopMusic };
}
