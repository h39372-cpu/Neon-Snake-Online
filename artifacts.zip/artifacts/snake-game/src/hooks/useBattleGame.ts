import { useState, useEffect, useCallback, useRef } from "react";
import type { Direction, Point, Speed, GameSettings } from "./useSnakeGame";
export type { Direction, Point };

export type BattleRule = "elimination" | "absorption";
export type BattleState = "idle" | "playing" | "paused" | "gameOver";
export type Winner = "p1" | "p2" | "draw" | null;

export interface BattleSettings {
  speed: Speed;
  gridSize: number;
  rule: BattleRule;
  musicEnabled: boolean;
  sfxEnabled: boolean;
}

const SPEED_DELAY: Record<Speed, number> = {
  slow: 220,
  normal: 130,
  fast: 70,
};

const FOOD_COUNT = 3;

function randomPoints(
  snake1: Point[],
  snake2: Point[],
  existing: Point[],
  gridSize: number,
  count: number
): Point[] {
  const occupied = new Set([
    ...snake1.map((s) => `${s.x},${s.y}`),
    ...snake2.map((s) => `${s.x},${s.y}`),
    ...existing.map((s) => `${s.x},${s.y}`),
  ]);
  const foods: Point[] = [];
  while (foods.length < count) {
    const f: Point = {
      x: Math.floor(Math.random() * gridSize),
      y: Math.floor(Math.random() * gridSize),
    };
    const key = `${f.x},${f.y}`;
    if (!occupied.has(key)) {
      occupied.add(key);
      foods.push(f);
    }
  }
  return foods;
}

function makeP1Snake(gridSize: number): Point[] {
  const mid = Math.floor(gridSize / 2);
  return [
    { x: 5, y: mid },
    { x: 4, y: mid },
    { x: 3, y: mid },
  ];
}

function makeP2Snake(gridSize: number): Point[] {
  const mid = Math.floor(gridSize / 2);
  return [
    { x: gridSize - 6, y: mid + 1 },
    { x: gridSize - 5, y: mid + 1 },
    { x: gridSize - 4, y: mid + 1 },
  ];
}

function nextHead(head: Point, dir: Direction): Point {
  switch (dir) {
    case "UP":    return { x: head.x, y: head.y - 1 };
    case "DOWN":  return { x: head.x, y: head.y + 1 };
    case "LEFT":  return { x: head.x - 1, y: head.y };
    case "RIGHT": return { x: head.x + 1, y: head.y };
  }
}

function hitWall(p: Point, gridSize: number): boolean {
  return p.x < 0 || p.x >= gridSize || p.y < 0 || p.y >= gridSize;
}

function hitSelf(head: Point, snake: Point[]): boolean {
  // Skip last segment (it moves away)
  for (let i = 0; i < snake.length - 1; i++) {
    if (snake[i].x === head.x && snake[i].y === head.y) return true;
  }
  return false;
}

function findBodyHit(head: Point, snake: Point[]): number {
  // Returns index in snake where head hits body (-1 if none)
  // We skip index 0 (head) and check body
  for (let i = 1; i < snake.length; i++) {
    if (snake[i].x === head.x && snake[i].y === head.y) return i;
  }
  return -1;
}

function samePoint(a: Point, b: Point): boolean {
  return a.x === b.x && a.y === b.y;
}

export function useBattleGame() {
  const [settings, setSettings] = useState<BattleSettings>({
    speed: "normal",
    gridSize: 35,
    rule: "elimination",
    musicEnabled: true,
    sfxEnabled: true,
  });

  const gridSize = settings.gridSize;

  const [snake1, setSnake1] = useState<Point[]>(() => makeP1Snake(gridSize));
  const [snake2, setSnake2] = useState<Point[]>(() => makeP2Snake(gridSize));
  const [foods, setFoods] = useState<Point[]>(() => {
    const s1 = makeP1Snake(gridSize);
    const s2 = makeP2Snake(gridSize);
    return randomPoints(s1, s2, [], gridSize, FOOD_COUNT);
  });
  const [dir1, setDir1] = useState<Direction>("RIGHT");
  const [dir2, setDir2] = useState<Direction>("LEFT");
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);
  const [gameState, setGameState] = useState<BattleState>("idle");
  const [winner, setWinner] = useState<Winner>(null);

  // Refs for game loop
  const s1Ref = useRef(snake1);
  const s2Ref = useRef(snake2);
  const foodsRef = useRef(foods);
  const d1Ref = useRef<Direction>("RIGHT");
  const d2Ref = useRef<Direction>("LEFT");
  const sc1Ref = useRef(0);
  const sc2Ref = useRef(0);
  const stateRef = useRef<BattleState>("idle");
  const settingsRef = useRef(settings);
  const loopRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Audio callbacks
  const onEatRef = useRef<(() => void) | null>(null);
  const onDieRef = useRef<(() => void) | null>(null);
  const onAbsorbRef = useRef<(() => void) | null>(null);

  useEffect(() => { settingsRef.current = settings; }, [settings]);

  const resetState = useCallback((gs: number) => {
    const p1 = makeP1Snake(gs);
    const p2 = makeP2Snake(gs);
    const f = randomPoints(p1, p2, [], gs, FOOD_COUNT);
    s1Ref.current = p1; setSnake1(p1);
    s2Ref.current = p2; setSnake2(p2);
    foodsRef.current = f; setFoods(f);
    d1Ref.current = "RIGHT"; setDir1("RIGHT");
    d2Ref.current = "LEFT";  setDir2("LEFT");
    sc1Ref.current = 0; setScore1(0);
    sc2Ref.current = 0; setScore2(0);
    setWinner(null);
  }, []);

  const startGame = useCallback(() => {
    resetState(settingsRef.current.gridSize);
    stateRef.current = "playing";
    setGameState("playing");
  }, [resetState]);

  const pauseGame = useCallback(() => {
    if (stateRef.current !== "playing") return;
    stateRef.current = "paused";
    setGameState("paused");
  }, []);

  const resumeGame = useCallback(() => {
    if (stateRef.current !== "paused") return;
    stateRef.current = "playing";
    setGameState("playing");
  }, []);

  const goToMenu = useCallback(() => {
    if (loopRef.current) clearTimeout(loopRef.current);
    stateRef.current = "idle";
    setGameState("idle");
    resetState(settingsRef.current.gridSize);
  }, [resetState]);

  const updateSettings = useCallback((partial: Partial<BattleSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      settingsRef.current = next;
      return next;
    });
  }, []);

  const endGame = useCallback((w: Winner) => {
    stateRef.current = "gameOver";
    setGameState("gameOver");
    setWinner(w);
    onDieRef.current?.();
  }, []);

  const tick = useCallback(() => {
    if (stateRef.current !== "playing") return;

    const { gridSize: gs, rule } = settingsRef.current;
    const cur1 = s1Ref.current;
    const cur2 = s2Ref.current;

    const newH1 = nextHead(cur1[0], d1Ref.current);
    const newH2 = nextHead(cur2[0], d2Ref.current);

    let p1Dead = false;
    let p2Dead = false;

    // Wall collisions
    if (hitWall(newH1, gs)) p1Dead = true;
    if (hitWall(newH2, gs)) p2Dead = true;

    // Self collisions
    if (!p1Dead && hitSelf(newH1, cur1)) p1Dead = true;
    if (!p2Dead && hitSelf(newH2, cur2)) p2Dead = true;

    if (p1Dead && p2Dead) { endGame("draw"); return; }
    if (p1Dead) { endGame("p2"); return; }
    if (p2Dead) { endGame("p1"); return; }

    // Head-to-head collision
    if (samePoint(newH1, newH2)) {
      // Larger snake wins; tie → draw
      if (cur1.length > cur2.length) { endGame("p1"); return; }
      if (cur2.length > cur1.length) { endGame("p2"); return; }
      endGame("draw");
      return;
    }

    // Body collision checks
    const h1HitsP2Body = findBodyHit(newH1, cur2);
    const h2HitsP1Body = findBodyHit(newH2, cur1);

    let newSnake1 = cur1;
    let newSnake2 = cur2;
    let newFoods = [...foodsRef.current];

    if (rule === "elimination") {
      if (h1HitsP2Body !== -1) { endGame("p2"); return; }
      if (h2HitsP1Body !== -1) { endGame("p1"); return; }
    } else {
      // Absorption: attacker eats victim's tail from hit segment
      if (h1HitsP2Body !== -1 && h2HitsP1Body !== -1) {
        // Both hit simultaneously → draw
        endGame("draw");
        return;
      }

      if (h1HitsP2Body !== -1) {
        // P1 eats P2 from segment h1HitsP2Body onwards
        const absorbed = cur2.slice(h1HitsP2Body); // segments eaten
        const bonusLen = absorbed.length;
        newSnake2 = [newH2, ...cur2.slice(0, h1HitsP2Body)]; // P2 trimmed
        // P1 grows by absorbed count (prepend head then extend tail)
        newSnake1 = [newH1, ...cur1, ...Array(bonusLen).fill(cur1[cur1.length - 1])];
        const ns1 = sc1Ref.current + bonusLen * 5;
        sc1Ref.current = ns1;
        setScore1(ns1);
        onAbsorbRef.current?.();
        // If P2 becomes just a head or empty, P1 wins
        if (newSnake2.length <= 1) { endGame("p1"); return; }
      } else if (h2HitsP1Body !== -1) {
        // P2 eats P1 from segment h2HitsP1Body onwards
        const absorbed = cur1.slice(h2HitsP1Body);
        const bonusLen = absorbed.length;
        newSnake1 = [newH1, ...cur1.slice(0, h2HitsP1Body)]; // P1 trimmed
        newSnake2 = [newH2, ...cur2, ...Array(bonusLen).fill(cur2[cur2.length - 1])];
        const ns2 = sc2Ref.current + bonusLen * 5;
        sc2Ref.current = ns2;
        setScore2(ns2);
        onAbsorbRef.current?.();
        if (newSnake1.length <= 1) { endGame("p2"); return; }
      }
    }

    // Normal movement (if no absorption happened, apply standard move)
    if (rule === "elimination" || (h1HitsP2Body === -1 && h2HitsP1Body === -1)) {
      newSnake1 = [newH1, ...cur1.slice(0, -1)];
      newSnake2 = [newH2, ...cur2.slice(0, -1)];
    } else if (h1HitsP2Body !== -1) {
      // P1 already has newH1, but P2 needs normal move
      newSnake2 = [newH2, ...newSnake2.slice(1, -1)]; // move P2 forward
    } else if (h2HitsP1Body !== -1) {
      newSnake1 = [newH1, ...newSnake1.slice(1, -1)];
    }

    // Food eating
    let ateP1 = false;
    let ateP2 = false;
    const remainingFoods: Point[] = [];

    for (const f of newFoods) {
      const p1Ate = samePoint(newSnake1[0], f);
      const p2Ate = samePoint(newSnake2[0], f);
      if (p1Ate || p2Ate) {
        if (p1Ate) {
          newSnake1 = [...newSnake1, newSnake1[newSnake1.length - 1]];
          const ns = sc1Ref.current + 10;
          sc1Ref.current = ns; setScore1(ns);
          ateP1 = true;
        }
        if (p2Ate) {
          newSnake2 = [...newSnake2, newSnake2[newSnake2.length - 1]];
          const ns = sc2Ref.current + 10;
          sc2Ref.current = ns; setScore2(ns);
          ateP2 = true;
        }
      } else {
        remainingFoods.push(f);
      }
    }

    if (ateP1 || ateP2) {
      const newSpawn = randomPoints(newSnake1, newSnake2, remainingFoods, gs, newFoods.length - remainingFoods.length);
      newFoods = [...remainingFoods, ...newSpawn];
      onEatRef.current?.();
    }

    s1Ref.current = newSnake1; setSnake1([...newSnake1]);
    s2Ref.current = newSnake2; setSnake2([...newSnake2]);
    foodsRef.current = newFoods; setFoods([...newFoods]);
  }, [endGame]);

  // Game loop
  useEffect(() => {
    if (gameState !== "playing") {
      if (loopRef.current) clearTimeout(loopRef.current);
      return;
    }
    const delay = SPEED_DELAY[settings.speed];
    loopRef.current = setTimeout(() => {
      tick();
    }, delay);
    return () => {
      if (loopRef.current) clearTimeout(loopRef.current);
    };
  }, [gameState, snake1, snake2, settings.speed, tick]);

  // Keyboard controls — P1: WASD, P2: Arrow keys
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;

      switch (e.key) {
        // P1: WASD
        case "w": case "W":
          if (d1Ref.current !== "DOWN")  { d1Ref.current = "UP";    setDir1("UP"); }
          e.preventDefault(); break;
        case "s": case "S":
          if (d1Ref.current !== "UP")    { d1Ref.current = "DOWN";  setDir1("DOWN"); }
          e.preventDefault(); break;
        case "a": case "A":
          if (d1Ref.current !== "RIGHT") { d1Ref.current = "LEFT";  setDir1("LEFT"); }
          e.preventDefault(); break;
        case "d": case "D":
          if (d1Ref.current !== "LEFT")  { d1Ref.current = "RIGHT"; setDir1("RIGHT"); }
          e.preventDefault(); break;

        // P2: Arrow keys
        case "ArrowUp":
          if (d2Ref.current !== "DOWN")  { d2Ref.current = "UP";    setDir2("UP"); }
          e.preventDefault(); break;
        case "ArrowDown":
          if (d2Ref.current !== "UP")    { d2Ref.current = "DOWN";  setDir2("DOWN"); }
          e.preventDefault(); break;
        case "ArrowLeft":
          if (d2Ref.current !== "RIGHT") { d2Ref.current = "LEFT";  setDir2("LEFT"); }
          e.preventDefault(); break;
        case "ArrowRight":
          if (d2Ref.current !== "LEFT")  { d2Ref.current = "RIGHT"; setDir2("RIGHT"); }
          e.preventDefault(); break;

        // Pause
        case "Escape":
        case "p": case "P":
          if (stateRef.current === "playing") pauseGame();
          else if (stateRef.current === "paused") resumeGame();
          break;
        case " ":
          if (stateRef.current === "playing") pauseGame();
          else if (stateRef.current === "paused") resumeGame();
          e.preventDefault(); break;
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [pauseGame, resumeGame]);

  return {
    snake1, snake2, foods, dir1, dir2,
    score1, score2, gameState, winner, settings,
    startGame, pauseGame, resumeGame, goToMenu, updateSettings,
    onEatRef, onDieRef, onAbsorbRef,
  };
}
