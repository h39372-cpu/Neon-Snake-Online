import { useState, useEffect, useCallback, useRef } from "react";

export type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";
export type GameState = "idle" | "playing" | "paused" | "gameOver";
export type Speed = "slow" | "normal" | "fast";
export type ItemType = "food" | "star" | "gold" | "speed" | "shorten" | "poison" | "magnet";

export interface Point { x: number; y: number; }

export interface Item {
  id: number;
  x: number;
  y: number;
  type: ItemType;
  expiresAt: number; // game-tick count when item disappears; 0 = never
}

export interface ActiveEffects {
  speed: number;   // ticks remaining (2x faster)
  poison: number;  // ticks remaining (1.8x slower)
  magnet: number;  // ticks remaining (attracts nearest food each tick)
}

export interface GameSettings {
  speed: Speed;
  gridSize: number;
  musicEnabled: boolean;
  sfxEnabled: boolean;
}

export const SPEED_DELAY: Record<Speed, number> = {
  slow: 220,
  normal: 130,
  fast: 70,
};

interface ItemCfg {
  emoji: string;
  color: string;
  glow: string;
  weight: number;  // spawn probability weight
  score: number;
  grow: number;    // segments added (negative = removed)
  effectTicks: number;
  expire: number;  // ticks until item disappears (0 = permanent)
}

export const ITEM_CONFIG: Record<ItemType, ItemCfg> = {
  food:    { emoji: "🍎", color: "#ff5555", glow: "#ff2222", weight: 55, score: 1,  grow:  1, effectTicks:  0, expire:  0 },
  star:    { emoji: "⭐", color: "#ffee44", glow: "#ffcc00", weight: 25, score: 3,  grow:  1, effectTicks:  0, expire: 80 },
  gold:    { emoji: "🏅", color: "#ffaa00", glow: "#ff7700", weight: 10, score: 10, grow:  1, effectTicks:  0, expire: 50 },
  speed:   { emoji: "⚡", color: "#00ffff", glow: "#00ccff", weight:  4, score: 0,  grow:  0, effectTicks: 28, expire: 60 },
  shorten: { emoji: "🔵", color: "#0099ff", glow: "#0055ff", weight:  3, score: 2,  grow: -3, effectTicks:  0, expire: 70 },
  poison:  { emoji: "💜", color: "#cc44ff", glow: "#aa00ff", weight:  2, score: 0,  grow: -5, effectTicks: 22, expire: 80 },
  magnet:  { emoji: "🧲", color: "#ff9900", glow: "#ff6600", weight:  1, score: 0,  grow:  0, effectTicks: 28, expire: 70 },
};

const MAX_ITEMS = 5;
const MIN_FOOD = 2;
let _itemId = 0;

function pickType(exclude: ItemType[] = []): ItemType {
  const pool = (Object.keys(ITEM_CONFIG) as ItemType[]).filter(t => !exclude.includes(t));
  const total = pool.reduce((s, t) => s + ITEM_CONFIG[t].weight, 0);
  let r = Math.random() * total;
  for (const t of pool) { r -= ITEM_CONFIG[t].weight; if (r <= 0) return t; }
  return "food";
}

function spawnItem(
  snake: Point[], existing: Item[], gridSize: number, type?: ItemType, tickCount = 0
): Item {
  const occupied = new Set([
    ...snake.map(s => `${s.x},${s.y}`),
    ...existing.map(i => `${i.x},${i.y}`),
  ]);
  let x: number, y: number;
  let attempts = 0;
  do {
    x = Math.floor(Math.random() * gridSize);
    y = Math.floor(Math.random() * gridSize);
    attempts++;
  } while (occupied.has(`${x},${y}`) && attempts < 500);
  const t = type ?? pickType();
  const cfg = ITEM_CONFIG[t];
  return { id: ++_itemId, x, y, type: t, expiresAt: cfg.expire > 0 ? tickCount + cfg.expire : 0 };
}

function replenish(snake: Point[], cur: Item[], gridSize: number, tickCount: number): Item[] {
  let items = [...cur];
  const foodCount = items.filter(i => i.type === "food").length;
  let foodNeeded = Math.max(0, MIN_FOOD - foodCount);
  let slots = MAX_ITEMS - items.length;
  while (foodNeeded-- > 0 && slots-- > 0) items.push(spawnItem(snake, items, gridSize, "food", tickCount));
  slots = MAX_ITEMS - items.length;
  while (slots-- > 0) items.push(spawnItem(snake, items, gridSize, undefined, tickCount));
  return items;
}

function makeInitialSnake(): Point[] {
  return [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useSnakeGame() {
  const [settings, setSettings] = useState<GameSettings>({
    speed: "normal", gridSize: 35, musicEnabled: true, sfxEnabled: true,
  });

  const [snake, setSnake] = useState<Point[]>(makeInitialSnake);
  const [items, setItems] = useState<Item[]>([]);
  const [direction, setDirection] = useState<Direction>("RIGHT");
  const [gameState, setGameState] = useState<GameState>("idle");
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    const s = localStorage.getItem("neonSnakeHighScore");
    return s ? parseInt(s, 10) : 0;
  });
  const [activeEffects, setActiveEffects] = useState<ActiveEffects>({ speed: 0, poison: 0, magnet: 0 });

  // Refs — values used inside game-loop callbacks
  const dirRef      = useRef<Direction>("RIGHT");
  const stateRef    = useRef<GameState>("idle");
  const snakeRef    = useRef<Point[]>(makeInitialSnake());
  const itemsRef    = useRef<Item[]>([]);
  const scoreRef    = useRef(0);
  const hiRef       = useRef(highScore);
  const settRef     = useRef(settings);
  const effRef      = useRef<ActiveEffects>({ speed: 0, poison: 0, magnet: 0 });
  const tickRef     = useRef(0);
  const loopRef     = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Exposed audio callbacks
  const onEatRef = useRef<((type: ItemType) => void) | null>(null);
  const onDieRef = useRef<(() => void) | null>(null);

  useEffect(() => { settRef.current = settings; }, [settings]);
  useEffect(() => { hiRef.current = highScore; }, [highScore]);

  // ── Reset ──────────────────────────────────────────────────────────────────
  const resetState = useCallback((gridSize: number) => {
    const s = makeInitialSnake();
    const its = replenish(s, [], gridSize, 0);
    snakeRef.current = s; setSnake(s);
    itemsRef.current = its; setItems(its);
    dirRef.current = "RIGHT"; setDirection("RIGHT");
    scoreRef.current = 0; setScore(0);
    effRef.current = { speed: 0, poison: 0, magnet: 0 };
    tickRef.current = 0;
    setActiveEffects({ speed: 0, poison: 0, magnet: 0 });
  }, []);

  const startGame = useCallback(() => {
    resetState(settRef.current.gridSize);
    stateRef.current = "playing";
    setGameState("playing");
  }, [resetState]);

  const pauseGame = useCallback(() => {
    if (stateRef.current !== "playing") return;
    stateRef.current = "paused"; setGameState("paused");
  }, []);

  const resumeGame = useCallback(() => {
    if (stateRef.current !== "paused") return;
    stateRef.current = "playing"; setGameState("playing");
  }, []);

  const goToMenu = useCallback(() => {
    if (loopRef.current) clearTimeout(loopRef.current);
    stateRef.current = "idle"; setGameState("idle");
    resetState(settRef.current.gridSize);
  }, [resetState]);

  const updateSettings = useCallback((partial: Partial<GameSettings>) => {
    setSettings(prev => {
      const next = { ...prev, ...partial };
      settRef.current = next;
      return next;
    });
  }, []);

  // ── Kill snake ─────────────────────────────────────────────────────────────
  const killSnake = useCallback(() => {
    stateRef.current = "gameOver"; setGameState("gameOver");
    onDieRef.current?.();
    const s = scoreRef.current;
    if (s > hiRef.current) {
      hiRef.current = s; setHighScore(s);
      localStorage.setItem("neonSnakeHighScore", String(s));
    }
  }, []);

  // ── Main tick ──────────────────────────────────────────────────────────────
  const tick = useCallback(() => {
    if (stateRef.current !== "playing") return;

    const { gridSize } = settRef.current;
    const cur = snakeRef.current;
    const head = cur[0];
    const tc = ++tickRef.current;

    // Move head
    let nx = head.x, ny = head.y;
    switch (dirRef.current) {
      case "UP":    ny--; break;
      case "DOWN":  ny++; break;
      case "LEFT":  nx--; break;
      case "RIGHT": nx++; break;
    }

    // Wall collision
    if (nx < 0 || nx >= gridSize || ny < 0 || ny >= gridSize) { killSnake(); return; }

    // Self collision (skip last tail segment — it will vacate)
    for (let i = 0; i < cur.length - 1; i++) {
      if (cur[i].x === nx && cur[i].y === ny) { killSnake(); return; }
    }

    const newHead: Point = { x: nx, y: ny };

    // ── Magnet: pull nearest food 1 cell toward head ─────────────────────────
    let curItems = itemsRef.current;
    if (effRef.current.magnet > 0) {
      const foodTypes: ItemType[] = ["food", "star", "gold"];
      const foodItems = curItems.filter(i => foodTypes.includes(i.type));
      if (foodItems.length > 0) {
        let nearest = foodItems[0];
        let minDist = Math.abs(nearest.x - nx) + Math.abs(nearest.y - ny);
        for (const fi of foodItems) {
          const d = Math.abs(fi.x - nx) + Math.abs(fi.y - ny);
          if (d < minDist) { minDist = d; nearest = fi; }
        }
        if (minDist > 1) {
          const dx = nx - nearest.x, dy = ny - nearest.y;
          let mx = nearest.x, my = nearest.y;
          if (Math.abs(dx) >= Math.abs(dy)) mx += dx > 0 ? 1 : -1;
          else                              my += dy > 0 ? 1 : -1;
          const snakeSet = new Set(cur.map(s => `${s.x},${s.y}`));
          const others = curItems.filter(i => i.id !== nearest.id);
          if (!snakeSet.has(`${mx},${my}`) && !others.some(i => i.x === mx && i.y === my)) {
            curItems = curItems.map(i => i.id === nearest.id ? { ...i, x: mx, y: my } : i);
          }
        }
      }
    }

    // ── Expire items ─────────────────────────────────────────────────────────
    curItems = curItems.filter(i => i.expiresAt === 0 || i.expiresAt > tc);

    // ── Check item collision ─────────────────────────────────────────────────
    let newSnake = [newHead, ...cur.slice(0, -1)];
    const hitItem = curItems.find(i => i.x === nx && i.y === ny) ?? null;

    if (hitItem) {
      const cfg = ITEM_CONFIG[hitItem.type];
      curItems = curItems.filter(i => i.id !== hitItem.id);

      // Score
      if (cfg.score > 0) {
        const ns = scoreRef.current + cfg.score;
        scoreRef.current = ns; setScore(ns);
      }

      // Grow / shrink
      if (cfg.grow > 0) {
        const tail = cur[cur.length - 1];
        for (let g = 0; g < cfg.grow; g++) newSnake.push(tail);
      } else if (cfg.grow < 0) {
        const remove = Math.min(-cfg.grow, newSnake.length - 1);
        newSnake = newSnake.slice(0, newSnake.length - remove);
      }

      // Effects
      const eff = { ...effRef.current };
      if (hitItem.type === "speed")   { eff.speed  = cfg.effectTicks; eff.poison = 0; }
      if (hitItem.type === "poison")  { eff.poison = cfg.effectTicks; eff.speed  = 0; }
      if (hitItem.type === "magnet")  { eff.magnet = cfg.effectTicks; }
      effRef.current = eff;
      setActiveEffects({ ...eff });

      onEatRef.current?.(hitItem.type);
    }

    // ── Tick-down active effects ──────────────────────────────────────────────
    const prev = effRef.current;
    const newEff: ActiveEffects = {
      speed:  Math.max(0, prev.speed  - 1),
      poison: Math.max(0, prev.poison - 1),
      magnet: Math.max(0, prev.magnet - 1),
    };
    effRef.current = newEff;
    if (newEff.speed !== prev.speed || newEff.poison !== prev.poison || newEff.magnet !== prev.magnet) {
      setActiveEffects({ ...newEff });
    }

    // ── Replenish items & commit ──────────────────────────────────────────────
    curItems = replenish(newSnake, curItems, gridSize, tc);
    itemsRef.current = curItems; setItems([...curItems]);
    snakeRef.current = newSnake; setSnake([...newSnake]);
  }, [killSnake]);

  // ── Game loop ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (gameState !== "playing") {
      if (loopRef.current) clearTimeout(loopRef.current);
      return;
    }
    const base = SPEED_DELAY[settings.speed];
    let delay = base;
    if (activeEffects.speed  > 0) delay = Math.round(base * 0.5);
    else if (activeEffects.poison > 0) delay = Math.round(base * 1.8);
    loopRef.current = setTimeout(tick, delay);
    return () => { if (loopRef.current) clearTimeout(loopRef.current); };
  }, [gameState, snake, settings.speed, activeEffects, tick]);

  // ── Keyboard ───────────────────────────────────────────────────────────────
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT") return;
      switch (e.key) {
        case "ArrowUp":    case "w": case "W": if (dirRef.current !== "DOWN")  dirRef.current = "UP";    e.preventDefault(); break;
        case "ArrowDown":  case "s": case "S": if (dirRef.current !== "UP")    dirRef.current = "DOWN";  e.preventDefault(); break;
        case "ArrowLeft":  case "a": case "A": if (dirRef.current !== "RIGHT") dirRef.current = "LEFT";  e.preventDefault(); break;
        case "ArrowRight": case "d": case "D": if (dirRef.current !== "LEFT")  dirRef.current = "RIGHT"; e.preventDefault(); break;
        case "Escape": case "p": case "P":
          stateRef.current === "playing" ? pauseGame() : stateRef.current === "paused" ? resumeGame() : null; break;
        case " ":
          stateRef.current === "idle" ? startGame() : stateRef.current === "playing" ? pauseGame() : stateRef.current === "paused" ? resumeGame() : null;
          e.preventDefault(); break;
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [pauseGame, resumeGame, startGame]);

  return {
    snake, items, direction, gameState, score, highScore, settings, activeEffects,
    startGame, pauseGame, resumeGame, goToMenu, updateSettings,
    onEatRef, onDieRef,
  };
}
