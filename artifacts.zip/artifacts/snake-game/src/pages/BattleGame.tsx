import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { useBattleGame } from "@/hooks/useBattleGame";
import type { BattleRule } from "@/hooks/useBattleGame";
import { useAudio } from "@/hooks/useAudio";
import BattleCanvas from "@/components/game/BattleCanvas";
import BattleHUD from "@/components/game/BattleHUD";
import BattleOverlay from "@/components/game/BattleOverlay";
import BattlePauseOverlay from "@/components/game/BattlePauseOverlay";
import { Play, Skull, Zap } from "lucide-react";

const RULE_META: Record<BattleRule, { label: string; sublabel: string; color: string; Icon: typeof Skull }> = {
  elimination: { label: "致命模式", sublabel: "撞到對手即淘汰", color: "#ff44cc", Icon: Skull },
  absorption:  { label: "吞噬模式", sublabel: "吃到對手身體即增大", color: "#ffaa00", Icon: Zap  },
};

function BattleStartOverlay({ rule, onStart, onMenu }: { rule: BattleRule; onStart: () => void; onMenu: () => void }) {
  const meta = RULE_META[rule];
  const { Icon } = meta;
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/75 backdrop-blur-sm">
      <div className="scanline-overlay" />

      <div className="mb-6 text-center animate-flicker">
        <h1 className="text-5xl font-black tracking-widest neon-text-cyan mb-1">NEON</h1>
        <h1 className="text-5xl font-black tracking-widest neon-text-magenta">SNAKE</h1>
      </div>

      <div className="mb-6 flex items-center gap-2 text-base font-bold tracking-wider" style={{ color: meta.color }}>
        <Icon size={18} />
        <span>{meta.label}</span>
      </div>
      <p className="mb-8 text-sm text-muted-foreground/60 tracking-widest">{meta.sublabel}</p>

      <div className="mb-8 flex gap-10 text-sm tracking-widest">
        <div className="text-center">
          <div className="text-xs mb-1" style={{ color: "rgba(0,255,255,0.5)" }}>玩家 1</div>
          <div className="font-mono font-bold" style={{ color: "#00ffff" }}>WASD</div>
        </div>
        <div className="text-center">
          <div className="text-xs mb-1" style={{ color: "rgba(255,68,204,0.5)" }}>玩家 2</div>
          <div className="font-mono font-bold" style={{ color: "#ff44cc" }}>方向鍵</div>
        </div>
      </div>

      <div className="flex flex-col gap-3 w-60">
        <button onClick={onStart}
          className="neon-btn flex items-center justify-center gap-2 py-3.5 px-6 border-2 font-bold text-base tracking-widest transition-all"
          style={{ borderColor: meta.color, color: meta.color, boxShadow: `0 0 10px ${meta.color}44` }}>
          <Play size={18} fill="currentColor" /> 開始對戰
        </button>
        <button onClick={onMenu}
          className="neon-btn flex items-center justify-center gap-2 py-2.5 px-6 border border-muted-foreground/20 text-muted-foreground/50 font-bold text-sm tracking-widest hover:text-foreground/70 transition-all">
          ← 返回選單
        </button>
      </div>
    </div>
  );
}

export default function BattleGame() {
  const params = useParams<{ rule?: string }>();
  const rule: BattleRule = params.rule === "absorption" ? "absorption" : "elimination";
  const [, navigate] = useLocation();

  const {
    snake1, snake2, foods, score1, score2,
    gameState, winner, settings,
    startGame, pauseGame, resumeGame, goToMenu, updateSettings,
    onEatRef, onDieRef,
  } = useBattleGame();

  const { playEat, playDie, playPause, playResume, startMusic, stopMusic } =
    useAudio(settings.musicEnabled, settings.sfxEnabled);

  onEatRef.current = () => playEat();
  onDieRef.current = playDie;

  // Apply rule + gridSize from URL on mount
  useEffect(() => {
    updateSettings({ rule, gridSize: 35 });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rule]);

  useEffect(() => {
    if (gameState === "playing" && settings.musicEnabled) startMusic();
    else stopMusic();
  }, [gameState, settings.musicEnabled, startMusic, stopMusic]);

  const handleStart = useCallback(() => startGame(), [startGame]);
  const handlePause = useCallback(() => { pauseGame(); playPause(); stopMusic(); }, [pauseGame, playPause, stopMusic]);
  const handleResume = useCallback(() => {
    resumeGame(); playResume();
    if (settings.musicEnabled) startMusic();
  }, [resumeGame, playResume, settings.musicEnabled, startMusic]);
  const handleMenu = useCallback(() => { stopMusic(); goToMenu(); navigate("/"); }, [goToMenu, stopMusic, navigate]);

  const handleToggleMusic = useCallback(() => {
    const next = !settings.musicEnabled;
    updateSettings({ musicEnabled: next });
    if (next && gameState === "playing") startMusic(); else stopMusic();
  }, [settings.musicEnabled, gameState, updateSettings, startMusic, stopMusic]);
  const handleToggleSfx = useCallback(() => updateSettings({ sfxEnabled: !settings.sfxEnabled }), [settings.sfxEnabled, updateSettings]);

  const tickRef = useRef(0);
  useEffect(() => { tickRef.current++; }, [snake1, snake2, foods]);

  return (
    <div className="relative flex flex-col items-center justify-start min-h-screen w-full pt-3 pb-4 px-2 select-none" data-testid="battle-page">
      <div className="flex items-center gap-3 mb-2">
        <span className="text-xs tracking-widest font-black opacity-50" style={{ color: RULE_META[rule].color }}>
          {RULE_META[rule].label.toUpperCase()}
        </span>
      </div>

      <div className="flex flex-col items-center">
        {(gameState === "playing" || gameState === "paused") && (
          <BattleHUD
            score1={score1} score2={score2}
            len1={snake1.length} len2={snake2.length}
            settings={settings}
            onPause={handlePause} onToggleMusic={handleToggleMusic} onToggleSfx={handleToggleSfx}
          />
        )}

        <div className="relative">
          <BattleCanvas snake1={snake1} snake2={snake2} foods={foods} gridSize={settings.gridSize} tick={tickRef.current} />

          {gameState === "idle" && (
            <BattleStartOverlay rule={rule} onStart={handleStart} onMenu={handleMenu} />
          )}
          {gameState === "paused" && (
            <BattlePauseOverlay score1={score1} score2={score2} onResume={handleResume} onRestart={handleStart} onMenu={handleMenu} />
          )}
          {gameState === "gameOver" && (
            <BattleOverlay winner={winner} score1={score1} score2={score2} len1={snake1.length} len2={snake2.length} onRestart={handleStart} onMenu={handleMenu} />
          )}
        </div>
      </div>
    </div>
  );
}
