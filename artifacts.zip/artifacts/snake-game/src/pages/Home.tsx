import { useState } from "react";
import { useLocation } from "wouter";
import { useUser, useClerk } from "@clerk/react";
import type { BattleRule } from "@/hooks/useBattleGame";
import type { GameSettings } from "@/hooks/useSnakeGame";
import ModeSelectOverlay from "@/components/game/ModeSelectOverlay";
import SettingsPanel from "@/components/game/SettingsPanel";
import LoginOverlay from "@/components/game/LoginOverlay";

const GUEST_KEY = "neonSnakeGuest";

export default function Home() {
  const [, navigate] = useLocation();
  const { isSignedIn, isLoaded } = useUser();
  const { signOut } = useClerk();

  const [guestMode, setGuestMode] = useState(() => sessionStorage.getItem(GUEST_KEY) === "1");
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<GameSettings>({
    speed: "normal", gridSize: 35, musicEnabled: true, sfxEnabled: true,
  });

  const highScore = parseInt(localStorage.getItem("neonSnakeHighScore") ?? "0", 10);

  const updateSettings = (partial: Partial<GameSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const handleBattle = (rule: BattleRule) => navigate(`/battle/${rule}`);

  const handleGuest = () => {
    sessionStorage.setItem(GUEST_KEY, "1");
    setGuestMode(true);
  };

  const handleSignOut = async () => {
    sessionStorage.removeItem(GUEST_KEY);
    setGuestMode(false);
    if (isSignedIn) {
      await signOut();
    }
  };

  const showGame = isSignedIn || guestMode;

  return (
    <div
      className="relative flex flex-col items-center justify-center min-h-screen w-full select-none"
      style={{ background: "#050510" }}
      data-testid="home-page"
    >
      {/* Decorative grid */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,255,0.04) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Mode select / login / settings */}
      <div className="relative w-full max-w-lg" style={{ minHeight: 520 }}>
        {!isLoaded ? (
          /* Loading state — show nothing while Clerk initializes */
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-xs text-muted-foreground tracking-widest animate-pulse">LOADING...</div>
          </div>
        ) : showGame ? (
          !showSettings ? (
            <ModeSelectOverlay
              highScore={highScore}
              onSolo={() => navigate("/solo")}
              onBattle={handleBattle}
              onSettings={() => setShowSettings(true)}
              onSignOut={handleSignOut}
              isGuest={!isSignedIn}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div style={{ width: 340 }}>
                <SettingsPanel
                  settings={settings}
                  onUpdate={updateSettings}
                  onClose={() => setShowSettings(false)}
                />
              </div>
            </div>
          )
        ) : (
          <LoginOverlay onGuest={handleGuest} />
        )}
      </div>
    </div>
  );
}
