import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useSnakeGame } from "@/hooks/useSnakeGame";
import type { ItemType } from "@/hooks/useSnakeGame";
import { useAudio } from "@/hooks/useAudio";
import GameCanvas from "@/components/game/GameCanvas";
import GameHUD from "@/components/game/GameHUD";
import ItemLegend from "@/components/game/ItemLegend";
import StartOverlay from "@/components/game/StartOverlay";
import PauseOverlay from "@/components/game/PauseOverlay";
import GameOverOverlay from "@/components/game/GameOverOverlay";
import SettingsPanel from "@/components/game/SettingsPanel";
import MobileControls from "@/components/game/MobileControls";

export default function SoloGame() {
  const [, navigate] = useLocation();

  const {
    snake, items, gameState, score, highScore,
    settings, activeEffects,
    startGame, pauseGame, resumeGame, goToMenu, updateSettings,
    onEatRef, onDieRef,
  } = useSnakeGame();

  const { playEat, playDie, playPause, playResume, startMusic, stopMusic } =
    useAudio(settings.musicEnabled, settings.sfxEnabled);

  const [showSettings, setShowSettings] = useState(false);
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  const prevHighRef = useRef(highScore);

  onEatRef.current = (_type: ItemType) => playEat();
  onDieRef.current = playDie;

  useEffect(() => {
    if (gameState === "playing" && settings.musicEnabled) startMusic();
    else stopMusic();
  }, [gameState, settings.musicEnabled, startMusic, stopMusic]);

  useEffect(() => {
    if (gameState === "gameOver") {
      setIsNewHighScore(score > prevHighRef.current);
      prevHighRef.current = Math.max(score, prevHighRef.current);
    }
  }, [gameState, score]);

  const handleStart = useCallback(() => { setIsNewHighScore(false); startGame(); }, [startGame]);
  const handlePause = useCallback(() => { pauseGame(); playPause(); stopMusic(); }, [pauseGame, playPause, stopMusic]);
  const handleResume = useCallback(() => {
    resumeGame(); playResume();
    if (settings.musicEnabled) startMusic();
  }, [resumeGame, playResume, settings.musicEnabled, startMusic]);
  const handleMenu = useCallback(() => { stopMusic(); goToMenu(); navigate("/"); }, [goToMenu, stopMusic, navigate]);

  const handleToggleMusic = useCallback(() => {
    const next = !settings.musicEnabled;
    updateSettings({ musicEnabled: next });
    if (next && gameState === "playing") startMusic(); else stopMusic();
  }, [settings.musicEnabled, gameState, updateSettings, startMusic, stopMusic]);

  const handleToggleSfx = useCallback(() => {
    updateSettings({ sfxEnabled: !settings.sfxEnabled });
  }, [settings.sfxEnabled, updateSettings]);

  const handleMobileDir = useCallback((dir: "UP" | "DOWN" | "LEFT" | "RIGHT") => {
    const map: Record<string, string> = { UP: "ArrowUp", DOWN: "ArrowDown", LEFT: "ArrowLeft", RIGHT: "ArrowRight" };
    window.dispatchEvent(new KeyboardEvent("keydown", { key: map[dir], bubbles: true }));
  }, []);

  const tickRef = useRef(0);
  useEffect(() => { tickRef.current++; }, [snake, items]);

  return (
    <div className="relative flex flex-col items-center justify-start min-h-screen w-full pt-3 pb-4 px-2 select-none" data-testid="game-page">
      <div className="flex items-center gap-3 mb-2">
        <span className="text-xs neon-text-cyan tracking-widest font-black opacity-60 animate-flicker">NEON SNAKE</span>
      </div>

      <div className="flex items-start gap-3 justify-center w-full">
        <div className="flex flex-col items-center">
          {(gameState === "playing" || gameState === "paused") && (
            <GameHUD
              score={score} highScore={highScore} snakeLength={snake.length}
              settings={settings} activeEffects={activeEffects}
              onPause={handlePause} onToggleMusic={handleToggleMusic} onToggleSfx={handleToggleSfx}
            />
          )}

          <div className="relative">
            <GameCanvas snake={snake} items={items} settings={settings} activeEffects={activeEffects} tick={tickRef.current} />

            {gameState === "idle" && !showSettings && (
              <StartOverlay highScore={highScore} onStart={handleStart} onSettings={() => setShowSettings(true)} />
            )}
            {gameState === "idle" && showSettings && (
              <SettingsPanel settings={settings} onUpdate={updateSettings} onClose={() => setShowSettings(false)} />
            )}
            {gameState === "playing" && showSettings && (
              <SettingsPanel settings={settings} onUpdate={updateSettings} onClose={() => setShowSettings(false)} />
            )}
            {gameState === "paused" && !showSettings && (
              <PauseOverlay score={score} onResume={handleResume} onRestart={handleStart} onSettings={() => setShowSettings(true)} onMenu={handleMenu} />
            )}
            {gameState === "paused" && showSettings && (
              <SettingsPanel settings={settings} onUpdate={updateSettings} onClose={() => setShowSettings(false)} />
            )}
            {gameState === "gameOver" && (
              <GameOverOverlay score={score} highScore={highScore} snakeLength={snake.length} isNewHighScore={isNewHighScore} onRestart={handleStart} onMenu={handleMenu} />
            )}
          </div>

          {gameState === "playing" && <MobileControls onDirection={handleMobileDir} />}
        </div>

        <div className="hidden sm:flex flex-col pt-1" style={{ paddingTop: (gameState === "playing" || gameState === "paused") ? 56 : 0 }}>
          <ItemLegend activeEffects={activeEffects} />
        </div>
      </div>

      {gameState === "idle" && (
        <button onClick={() => navigate("/")} className="mt-3 text-xs text-muted-foreground/40 tracking-widest hover:text-muted-foreground/70 transition-colors">
          ← 返回選單
        </button>
      )}
    </div>
  );
}
